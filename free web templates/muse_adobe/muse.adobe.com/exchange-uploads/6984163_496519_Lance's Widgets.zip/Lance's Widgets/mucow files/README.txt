This directory contains sample mucow files.

It includes the mucow files used to create all the items in the "Lance's Samples" library, plus some additional samples.

Mucow files can be used to embed HTML, CSS and javascript into Muse, along with some simple UI for users to specify options.

These sample mucow files may be used as examples to create your own mucow files.

To learn more about the mucow file format, visit http://mucowdocs.businesscatalyst.com
