

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="wireless, lamps, controllers, event lighting,  lighting, architectural led lighting, deco lights, led controllers," />
  <meta name="description" content="Astera LED-Technology is a manufacturer of wireless LED lights and lighting controllers for event lighting and architectural lighting." />
  <link href="/favicon.ico" rel="shortcut icon" type="image/x-icon" />


<title>Astera LED Technology - Wireless LED Solutions for Event and Architectural Lighting - Wireless Wall Washer (AL6)</title>
<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
<link href="jquery.bxslider.css" rel="stylesheet" />
<link rel="stylesheet" href="style.css" type="text/css">



<script>
var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42824105-1']);
  _gaq.push(['_trackPageview']);
  _gaq.push(['_trackPageLoadTime']);


(function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
	

</script>

<style type="text/css">

.item_pic {
	height: 400px;
}
/* DIRECTION CONTROLS (NEXT / PREV) */

.bx-wrapper .bx-prev {
	left: 10px;
	background: url(images/controls_normal.png) no-repeat 0 -32px;
	margin-left: -10px;
}

.bx-wrapper .bx-next {
	right: 10px;
	background: url(images/controls_normal.png) no-repeat -43px -32px;
	margin-right: -10px;
}

.bx-wrapper .bx-prev:hover {
	background-position: 0 0;
}

.bx-wrapper .bx-next:hover {
	background-position: -43px 0;
}

.bx-wrapper .bx-controls-direction a {
	position: absolute;
	top: 50%;
	margin-top: -16px;
	outline: 0;
	width: 32px;
	height: 32px;
	text-indent: -9999px;
	z-index: 9999;
}

.bx-wrapper .bx-controls-direction a.disabled {
	display: none;
}



</style>
</head>
<body>

<header class="gradient">
 <div class="wrapper_960" style="padding:0; width:960px;">
     <a href="index.php" class="asteraLogo"><img src="images/astera_logo.png" alt="Astera Led Lighting" title="Astera Led Lighting"></a>
      <div class="lang_wrap">
	  <a class="language">中文</a>
     </div>
     <ul class="navigation">
	 <li><a href="wireless.php" id="onlink">
	   无线</a></li>
	   <li><a href="architectural.php" >
	   建筑</a></li>

 		   <li><a href="about.php" >
	   关于我们</a></li>
	   <li><a href="contact_us.php" >
	   联系我们</a></li>
	        </ul>
 </div>  
</header>
<div class="lang_strip">
   <div class="wrapper_960">
      <ul>
         <li><a href="?lang=en">English</a></li>
         <li><a href="?lang=de">Deutsch</a></li>
		 <li><a href="?lang=es">Español</a></li>
         <li><a href="?lang=cn">中文</a></li>

		 
<!--
		 <li><a>French</a></li>
		 <li><a>Italien</a></li>
		 <li><a>Spanish</a></li>
-->
      </ul>
   </div>
 </div>


<script>
$(document).ready(function() {
	$(".language").click(function () {
		$(".lang_strip").slideToggle(500);
		return false;
	}); 
});
</script>



<div class="project_nav">
   <div class="wrapper_960">
    <ul class="project_navigation">
	   <li><a href="wireless.php">
	   无线</a></li>

	   <li><a href="products.php">
	   产品</a></li>

	  <li><a href="pal6.php" id="onlink2" >
	  无线洗墙灯</a></li>
     </ul>
   </div> 
 </div>

<!--Item Banner-->

<div class="details_banner">
  <div class="wrapper_960">
     <div class="item_pic">
     
         <ul class="slider2">
			<li><img src="images/product_images/AL6_1.png"/></li><li><img src="images/product_images/AL6_2.png"/></li><li><img src="images/product_images/AL6_3.png"/></li><li><img src="images/product_images/AL6_4.png"/></li><li><img src="images/product_images/AL6_5.png"/></li><li><img src="images/product_images/AL6_6.png"/></li><li><img src="images/product_images/AL6_7.png"/></li><li><img src="images/product_images/AL6_8.png"/></li>        </ul>
		
		
     </div>
     <div class="item_details">
		<h1>
	  无线洗墙灯</h1>
		<p class="item_code">
产品代码: AL6 series
</p>
		<p>
无线洗墙灯是简单活动照明和装饰照明最理想的选择。把它们直接放在墙边，打开，墙面就披上各种颜色，造出不同的灯光效果  。</p>


<a class="support_btn2" href="downloads.php">
  <span class="support_icon"></span>
  <span class="text_btn">客户支持和下载</span>
</a>

        <div class="socialBar" style="margin-top:20px;">
                    <div class="facebook">
                      <div class="fb-like" data-send="true" data-layout="button_count" data-width="120" data-show-faces="false" data-font="arial"></div>
                    </div>
                    <!--facebook_like-->
                    <div id="fb-root"></div>
                    <script>(function(d, s, id) {
                      var js, fjs = d.getElementsByTagName(s)[0];
                      if (d.getElementById(id)) return;
                      js = d.createElement(s); js.id = id;
                      js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
                      fjs.parentNode.insertBefore(js, fjs);
                    }(document, 'script', 'facebook-jssdk'));</script>
                    <!--facebook_like-->
                   <div class="twitter" data-size="small">
                      <a href="https://twitter.com/share" class="twitter-share-button" data-url="http://www.astera-led.com/" data-via="your_screen_name" data-lang="en">Tweet</a>
                   </div> 
                    <!--twitterbutton-->
                   <script>
				   !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
                   </script>
                   <!--twitterbutton-->
                   <div class="googleplus">
                   <div class="g-plusone" data-size="medium"></div>
                   </div>
                   <!--google+button-->
					<script type="text/javascript">
                    (function() {
                      var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
                      po.src = 'https://apis.google.com/js/plusone.js';
                      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
                    })();
                  </script>
                  <!--google+button-->
                </div><!--end of social bar-->
     </div>

	 
  </div>
</div>

<!--Item Details Banner-->

<div class="details_strip">
   <div class="wrapper_960">
      <div class="tech_specification">
		  <h2 class="tech_title">
		  技术说明</h2>
          <ul>
		  

		<li>
			<p class="category">光源：</p>
			<p class="cat_explain"> AL6-S 	96个子弹头LEDs(24X红，24X绿，24X蓝，24X白)  =12W RGB功率 <br>
            AAL6-M 	192个子弹头LEDs(48X红，48X绿，48X蓝，48X白)  =24W RGB功率 <br>
            AL6-L 	384个子弹头LEDs(96X红，96X绿，96X蓝，96X白)  =48W RGB功率
</p>
		</li>
		<li>
			<p class="category">光束角：</p>
			<p class="cat_explain">15度 </p>
		</li>
		<li>
			<p class="category">散光片：</p>
			<p class="cat_explain">容易安装的固定配件</p>
		</li>
		<li>
			<p class="category">电池：</p>
			<p class="cat_explain">内置式锂离子聚合物电池，可持续工作8-24小时</p>
		</li>
		<li>
			<p class="category">工作电压：</p>
			<p class="cat_explain">110-240V, 50/60Hz</p>
		</li>
		<li>
			<p class="category">无线模块：</p>
			<p class="cat_explain">868MHz接收范围达300米( US版本：902-928MHz/330码 )</p>
		</li>
		<li>
			<p class="category">DMX功能：</p>
			<p class="cat_explain"> 通过DMX插座或ART3  DMX发射机 实现DMX功能</p>
		</li>
		<li>
			<p class="category">外壳：</p>
			<p class="cat_explain">长条铝外壳，透明亚克力盖板</p>
		</li>
		<li>
			<p class="category">尺寸：</p>
			<p class="cat_explain"> AL6-S L25cm x H6.1cm x W6.1cm (L9.8” x H2.4” x W2.4”)  <br>
               AL6-M L50cm x H6.1cm x W6.1cm (L19.6” x H2.4” xW2.4”)<br>
               AL6-L L100cm x H6.1cm x W6.1cm (L39.2” x H2.4”x W2.4”) 

</p>
		</li>
		<li>
			<p class="category">重量：</p>
			<p class="cat_explain"> 1kg (2.2lb) <br>
            2 kg (4.4lb) <br>
            4 kg (8.8lb) 

</p>
		</li>
		<li>
			<p class="category">适用环境</p>
			<p class="cat_explain">户内&干燥时的户外</p>
		</li>
		<li>
			<p class="category">其他特征：</p>
			<p class="cat_explain">Gamma修正功能，温度补偿功能，颜色校准功能</p>
		</li>
		<li>
			<p class="category">固定配件：</p>
			<p class="cat_explain">电源线(产品内置电源)，散光片</p>
		</li>
		<li>
			<p class="category">应用范围：</p>
			<p class="cat_explain">桌子底部/家具照明，效果照明，洗墙照明，沙滩或植物照明</p>
		</li>




          </ul>
             <div class="clear"></div>

      </div><!--end of tech specification-->
  <div class="main_benefits">
	<h2 class="benefite_title">
	主要优点</h2>

    <ul>
		  

		<li>
			<p class="category">内置可充电电池</p>
		</li>
		<li>
			<p class="category">遥控控制</p>
		</li>
		<li>
			<p class="category">LED功率: 12-48W</p>
		</li>
		<li>
			<p class="category">无线DMX</p>
		</li>
		<li>
			<p class="category">无闪烁操作</p>
		</li>
		<li>
			<p class="category">独立操作</p>
		</li>



          </ul>
  </div><!--end of main benefits-->
   <div class="clear"></div>
   </div><!--end of wrapper960-->   
</div> <!--end of stails strip--> 
  
<div class="item_section">
    <div class="wrapper_960">
       <div class="section1">
		   <h2 class="compatible_lights_title">
		   配用遥控器
</h2>
           <ul>
             <li>
               <a href="javascript:;" class="non-clickable">
               <img width="150" height="150" src="images/compatible_lights/ARC1.png">
               <h3>ARC1</h3>
               </a>
             </li>
             <li>
               <a href="parc2.php">
               <img width="150" height="150" src="images/compatible_lights/ARC2.png">
               <h3>ARC2</h3>
               </a>
             </li>
             <li>
               <a href="part3.php">
               <img width="150" height="150" src="images/compatible_lights/ART3.png">
               <h3>ART3</h3>
               </a>
             </li>
             <li>
               <a href="part6.php">
               <img width="150" height="150" src="images/compatible_lights/AsteraTouch.png">
               <h3>AsteraBox™</h3>
               </a>
             </li>
           </ul>
       </div>
       <div class="border"></div>


       <div class="section2">
		   <h2 class="more_images">
		   更多图片</h2>
           <ul>
             <li>
               <img width="200" height="200" src="images/product_images/al6_m1.jpg" style="height:200px;width:200px;">
             </li>
             <li>
               <img width="200" height="200" src="images/product_images/al6_m2.png" style="height:200px;width:200px;">
             </li>
             <li>
               <img width="200" height="200" src="images/product_images/al6_m3.png" style="height:200px;width:200px;">
             </li>
           </ul>
           <div class="clear"></div>
       </div>
	   

       <div class="border"></div>
	   

	   <a href="pal3m.php" class="btn_left">
< 前一个产品</a>
	  <a href="pal7x.php" class="btn_right">
下一个产品 >
</a>
	  <a href="products.php" class="back_to_products clear">
返回产品</a>


      <div class="clear"></div>
    </div>  <!--end of wrapper-960-->  
</div>
<!--end of item section--> 



<footer>
  <div class="wrapper_960">
     <ul class="sitemap">
       <li>
	   <h3><a href="wireless.php">
	   活动照明灯具</a></h3>
         <ul class="bullets">
             <li>
			 <a href="wireless.php">
	   无线灯具</a>
             </li>
              <li>
			 <a href="products.php">
	   产品</a>
             </li>
              <li>
			 <a href="technology.php">
	   技术</a>
             </li>
              <li>
			 <a href="downloads.php">
	   客户支持&下载</a>
             </li>

         </ul>
       </li>
       <li>
	   <h3><a href="architectural.php">
	   建筑照明灯具</a></h3>
         <ul class="bullets">
             <li>
			 <a href="archchelsea.php">
	   现代时尚的零售照明灯具</a>
             </li>
              <li>
			 <a href="archgardens.php">
	   独特的吊灯</a>
             </li>
              <li>
			 <a href="archdj.php">
	   DJ专业灯具</a>
             </li>
              <li>
			 <a href="architsu.php">
	   餐饮照明</a>
             </li>
         </ul>
       </li>
	   
	   	    <li><h3>	<a href="green.php">  联系我们 </h3><ul class="bullets"><li><a href="green_bulbs.php"></a></li><li><a href="green_tubes.php"> </a></li><li>	<a href="green_street_light.php">				 				</a>             </li>			 			<li>				<a href="green_control_system.php">				  				</a>             </li>	       </ul> </li>		 	   
	   
       <li>
		 <h3>
		 <a href="about.php">
	   关于我们		</h3>
         <ul class="bullets">
             <li><a href="about.php">公司简介</a></li>

			
             <li>
             <a href="ManagementTeam.php">管理团队</a>
             </li>
			
			 <li>
			 <a href="contact_us.php">
			联系我们				</a>
			</li>
			<!--
			<li>
				<a href="careers.php">
				   				</a>
             </li>
			 -->
         </ul>
       </li>
       
	   

      
     </ul>
     <div class="footer_border"></div>
        <div class="sign_wrap">
		 <h3 class="sign_in">
		 申请更新和报价</h3>
        <form id="subscribe" action="shoot.php" method="post" name="subscribe" class="ajax_contact"  data-errorsClass='subscribe-error' data-successClass='subscribe-success'>
              <ul>
                  <li class="envelope"></li>
				  <li><input type="text" name="email" placeholder="您的邮箱地址" required/></li>
				  <li><button class="submit" type="submit" onClick="_gaq.push(['_trackEvent', 'TRK', 'Subscribe', 'pal6']);">
		 订阅产品简讯</button></li>
              </ul>
              <div class="clear"></div>
         </form>
       </div>   
     <ul class="face_tube">
         <li><a href="https://www.facebook.com/AsteraLEDTechnology" target="_blank" class="facebook_group"></a></li>
         <li><a href="https://twitter.com/AsteraGlobal" target="_blank" class="twitter_group"></a></li>
         <li><a href="http://www.youtube.com/user/AsteraLED" target="_blank" class="youtube"></a></li>
     </ul>
  </div>
  
  <div class="black_strip">
       <div class="wrapper_960">
		 <p class="copyright">
		 © 2007-2014 Astera LED Technology.版权所有</p>
         <p class="muze_studio"><a href="http://www.muze-studio.co.il" target="_blank">UX Design | Web Design by Muze Studio</a></p>

		        </div>
  </div>
</footer>

<script src="js/jquery.bxslider.min.js"></script>

<script type="text/javascript">

        $(document).ready(function() {		
 
			var slider2 = $('.slider2').bxSlider({
				autoStart: false ,
				infiniteLoop: true, 


		        speed: '1',
				pause: 3000
			});
				
});	

</script>


<script type="text/javascript" src="js/ajax_contact.js"></script>

</body>
</html>
