

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="wireless, lamps, controllers, event lighting,  lighting, architectural led lighting, deco lights, led controllers," />
  <meta name="description" content="Astera LED-Technology is a manufacturer of wireless LED lights and lighting controllers for event lighting and architectural lighting." />
  <link href="/favicon.ico" rel="shortcut icon" type="image/x-icon" />


<title>Astera LED Technology - Wireless LED Solutions for Event and Architectural Lighting - Wireless LED Lights</title>
  
<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
<link href="jquery.bxslider.css" rel="stylesheet" />
<link rel="stylesheet" href="style.css" type="text/css">


<script>
var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42824105-1']);
  _gaq.push(['_trackPageview']);
  _gaq.push(['_trackPageLoadTime']);


(function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
	

</script>

</head>
<body>

<header class="gradient">
 <div class="wrapper_960" style="padding:0; width:960px;">
     <a href="index.php" class="asteraLogo"><img src="images/astera_logo.png" alt="Astera Led Lighting" title="Astera Led Lighting"></a>
      <div class="lang_wrap">
	  <a class="language">中文</a>
     </div>
     <ul class="navigation">
	 <li><a href="wireless.php" id="onlink">
	   无线</a></li>
	   <li><a href="architectural.php" >
	   建筑</a></li>

 		   <li><a href="about.php" >
	   关于我们</a></li>
	   <li><a href="contact_us.php" >
	   联系我们</a></li>
	        </ul>
 </div>  
</header>
<div class="lang_strip">
   <div class="wrapper_960">
      <ul>
         <li><a href="?lang=en">English</a></li>
         <li><a href="?lang=de">Deutsch</a></li>
		 <li><a href="?lang=es">Español</a></li>
         <li><a href="?lang=cn">中文</a></li>

		 
<!--
		 <li><a>French</a></li>
		 <li><a>Italien</a></li>
		 <li><a>Spanish</a></li>
-->
      </ul>
   </div>
 </div>


<script>
$(document).ready(function() {
	$(".language").click(function () {
		$(".lang_strip").slideToggle(500);
		return false;
	}); 
});
</script>


<div class="project_nav">
   <div class="wrapper_960">
    <ul class="project_navigation">
	   <li><a href="wireless.php">
	   无线</a></li>

	   <li><a href="products.php" id="onclick2">
	   产品</a></li>

    
     </ul>
   </div> 
 </div>
 
<div class="banner_products" data-stellar-background-ratio="0.5">
    <div class="wrapper_960">
	  <h1 class="products_title">
	  Astera <br>无线<br>产品</h1>
    </div>
</div><!--end of banner wire-->




<div class="main_products">
  <div class="wrapper_960">
      <ul class="wireless_products">
    <li>
    <a href="pal1.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
市场上唯一的无线像素管           <br />
		   <span class="enter">
   >></span></p>

         </div>
      </div>
      <div class="item_image"><img src="images/product_overview/Wireless Pixel Tube.png"></div>
	  <div class="item_name">
像素管</div>
      </a>
    </li>
    <li>
    <a href="pal3s.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
袖珍、万能的桌上灯饰产品           <br />
		   <span class="enter">
   >></span></p>

         </div>
      </div>
      <div class="item_image"><img src="images/product_overview/Mini Lightdrop.png"></div>
	  <div class="item_name">
Mini Lightdrop™ 小光滴</div>
      </a>
    </li>
	
    <li>
    <a href="pax3.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
高效的多功能射灯           <br />
		   <span class="enter">
   >></span></p>


         </div>
      </div>
      <div class="item_image"><img src="images/product_overview/LightdropX.png"></div>
	  <div class="item_name">
Lightdrop™ 光滴</div>
      </a>
    </li>
    <li>
    <a href="pal6.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
用绚丽灯光改变室内装修效果           <br />
		   <span class="enter">
   >></span></p>

         </div>
      </div>
      <div class="item_image"><img src="images/product_overview/Wireless Wallwasher.png"></div>
	  <div class="item_name">
无线洗墙灯</div>
      </a>
    </li>
				 <!--
			 Removing AL7-L
    <li>
    <a href="pal7l.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
性能出众的轻量级射灯           <br />
		   <span class="enter">
   >></span></p>

         </div>
      </div>
      <div class="item_image"><img src="images/product_overview/Wireless Spotlight.png"></div>
	  <div class="item_name">
无线射灯</div>
      </a>
    </li>
	
	-->
	
	
    <li>
    <a href="pal7x.php">
      <div class="hover_it">
         <div class="item_btn"> <p class="item_explore">
目前市场上最大功率的无线射灯           <br />
		   <span class="enter">
   >></span></p>

         </div>
      </div>
      <div class="item_image"><img src="images/product_overview/Water-Resistant Spotlight.png"></div>
	  <div class="item_name">
无线防水射灯</div>
      </a>
    </li>
	
    <li>
    <a href="pax10.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
耀眼的户外照明效果           <br />
		   <span class="enter">
   >></span></p>

         </div>
      </div>
      <div class="item_image"><img src="images/product_overview/SpotMax.png"></div>
	  <div class="item_name">
SpotMax™ 顶级射灯</div>
      </a>
    </li>
	
    <li>
    <a href="parc2.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
便携式远程遥控器           <br />
		   <span class="enter">
   >></span></p>

         </div>
      </div>
      <div class="item_image"><img src="images/product_overview/RF LED Controller.png"></div>
	  <div class="item_name">
RF-控制器</div>
      </a>
    </li>
    <li>
    <a href="part6.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
专门为活动照明设计的先进控制器           <br />
		   <span class="enter">
   >></span></p>

         </div>
      </div>
      <div class="item_image"><img src="images/product_overview/AsteraBox-overview.png"></div>
	  <div class="item_name">
AsteraBox™</div>
      </a>
    </li>
	
	<!-- removing for now
    <li>
    <a href="phangers.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
Astera灯具配件套装           <br />
		   <span class="enter">
   >></span></p>

         </div>
      </div>
      <div class="item_image"><img src="images/product_overview/Hangers Holders Etc.png"></div>
	  <div class="item_name">
悬挂配件，支架，外壳等等</div>
      </a>
    </li>
	-->

     <li>
    <a href="pcases.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
充电箱、配件箱、保护箱           <br />
		   <span class="enter">
   >></span></p>

         </div>
      </div>
      <div class="item_image"><img src="images/product_overview/Cases.png"></div>
	  <div class="item_name">
各类配用箱子</div>
      </a>
    </li>

    <li>
    <a href="part3.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
可以结合您的DMX桌面控制台一起控制我们的灯具           <br />
		   <span class="enter">
   >></span></p>

         </div>
      </div>
      <div class="item_image"><img src="images/product_overview/Wireless DMX Transmitter.png"></div>
	  <div class="item_name">
无线DMX发射机</div>
      </a>
    </li>
	
    <li>
    <a href="pslide.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
来自意大利的发光家具           <br />
		   <span class="enter">
   >></span></p>


         </div>
      </div>
      <div class="item_image"><img src="images/product_overview/SLIDE.png"></div>
	  <div class="item_name">
SLIDE® PE产品</div>
      </a>
    </li>
	
    <li>
    <a href="pcenterpieces.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
最简便的桌面饰品           <br />
		   <span class="enter">
   >></span></p>


         </div>
      </div>
      <div class="item_image"><img src="images/product_overview/Table Centerpieces.png"></div>
	  <div class="item_name">
中央摆饰</div>
      </a>
    </li>
		
    <li>
    <a href="Portadecor.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
Portadecor活动照明家具公司           <br />
		   <span class="enter">
   >></span></p>


         </div>
      </div>
      <div class="item_image"><img src="images/product_overview/porta-astera.png"></div>
	  <div class="item_name">
</div>
      </a>
    </li>
	
	
  </ul>
  <span class="border"></span>
  
  <a href="downloads.php" class="downloads">
  客户支持和下载 
  </a>
  <div class="socialBar2">
                    <div class="facebook">
                      <div class="fb-like" data-send="true" data-layout="button_count" data-width="120" data-show-faces="false" data-font="arial"></div>
                    </div>
                    <!--facebook_like-->
                    <div id="fb-root"></div>
                    <script>(function(d, s, id) {
                      var js, fjs = d.getElementsByTagName(s)[0];
                      if (d.getElementById(id)) return;
                      js = d.createElement(s); js.id = id;
                      js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
                      fjs.parentNode.insertBefore(js, fjs);
                    }(document, 'script', 'facebook-jssdk'));</script>
                    <!--facebook_like-->
                   <div class="twitter" data-size="small">
                      <a href="https://twitter.com/share" class="twitter-share-button" data-url="http://www.astera-led.com/" data-via="your_screen_name" data-lang="en">Tweet</a>
                   </div> 
                    <!--twitterbutton-->
                   <script>
				   !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
                   </script>
                   <!--twitterbutton-->
                   <div class="googleplus">
                   <div class="g-plusone" data-size="medium"></div>
                   </div>
                   <!--google+button-->
					<script type="text/javascript">
                    (function() {
                      var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
                      po.src = 'https://apis.google.com/js/plusone.js';
                      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
                    })();
                  </script>
                  <!--google+button-->
                </div><!--end of social bar-->
  </div><!--end of wrapper--> 
</div><!--end of main_products-->


<div class="orangestrip">
     <div class="wrapper_960">
       <div class="slider2_wrapper">
                 <ul class="slider2">
				 		  <li>
                             <p class="quote">
								“I love the AL7-XXL.  I look forward to getting this equipment into the market”
                             </p>
                             <p class="signature">
								 Paul George <br>
								 LED LA
                             </p>
                          </li>
                          <li>
                             <p class="quote">
								"We very much enjoy the AL7-WXXL's - there really is nothing else like them available on the market"
                             </p>
                             <p class="signature">
								 Richard Tatum <br>
								 L&M Light & Sound
                             </p>
                          </li>
					 

						  <li>
						  <p class="quote">
						  "Astera rules! They are producing great products and thanks again for lighting up our events with your awesome products!"
						  </p>
						  <p class="signature">
						  Martin James <br>
Alaska Professional Entertainment
</p>
</li>
<li>
<p class="quote">
"The Astera lights are exceptional and all other producers of wireless lights pale in comparison. They helped position my company as the most innovative in event decoration"
</p>
<p class="signature">
Filip Hamerla <br>
Eventroom Poland
</p>
</li>
<li>
<p class="quote">
"All at Astera are really good to deal with. I hope to extend my line this year"
</p>
<p class="signature">
Greg Hodges <br>
Creative Uplighting
</p>
</li>
<li>
<p class="quote">
"Astera’s products and technology really blow my mind! I feel that with Astera products my company jumped a few steps ahead of the competition."
</p>
<p class="signature">
Nitzan Dagan <br>
SWIS-Solar Wireless Lights
</p>
</li>
<li>
<p class="quote">
"At the stand of Astera, I found some pretty interesting wireless LED lighting systems. They offer inflatable LED structures, balls, cubes, even table stretch covers. You can remote-control the speed and color of the LED lighting."
</p>
<p class="signature">
Michael Heipel<br>
WAN-IFRA
</p>
</li>
<li>
<p class="quote">
"Nicely done on the AsteraTouch™. The case is awesome, the tablet is awesome too. I can't wait to use it at an event. It’s a game changer! I love the color selector! AWESOME!"
</p>
<p class="signature">
Greg Hodges<br>
Creative Uplighting
</p>
</li>


<li>
<p class="quote">
"I received the fixtures and AsteraTouch™ for World of Coke today. We opened a couple and started using them with the AsteraTouch™. AWESOME! I love it! We already have other clients going nuts for them. I’ll have more orders coming very soon. Thank you for all your support"
</p>
<p class="signature">
Jason Block
<br>
Guitar Center Pro
</p>
</li>

<li>
<p class="quote">
"So I took along your uplights to an event where the client didn't schedule them, and I'm lighting up five windows that are prominent in the space (five medium Wallwashers and one AsteraTouch™). All I can say is … so easy! I love how easy you've made it"
</p>
<p class="signature">
Greg Hodges
<br>
Creative Uplighting
</p>
</li>


					 
                 </ul>
               </div>
     </div>
   </div>
   
    

<footer>
  <div class="wrapper_960">
     <ul class="sitemap">
       <li>
	   <h3><a href="wireless.php">
	   活动照明灯具</a></h3>
         <ul class="bullets">
             <li>
			 <a href="wireless.php">
	   无线灯具</a>
             </li>
              <li>
			 <a href="products.php">
	   产品</a>
             </li>
              <li>
			 <a href="technology.php">
	   技术</a>
             </li>
              <li>
			 <a href="downloads.php">
	   客户支持&下载</a>
             </li>

         </ul>
       </li>
       <li>
	   <h3><a href="architectural.php">
	   建筑照明灯具</a></h3>
         <ul class="bullets">
             <li>
			 <a href="archchelsea.php">
	   现代时尚的零售照明灯具</a>
             </li>
              <li>
			 <a href="archgardens.php">
	   独特的吊灯</a>
             </li>
              <li>
			 <a href="archdj.php">
	   DJ专业灯具</a>
             </li>
              <li>
			 <a href="architsu.php">
	   餐饮照明</a>
             </li>
         </ul>
       </li>
	   
	   	    <li><h3>	<a href="green.php">  联系我们 </h3><ul class="bullets"><li><a href="green_bulbs.php"></a></li><li><a href="green_tubes.php"> </a></li><li>	<a href="green_street_light.php">				 				</a>             </li>			 			<li>				<a href="green_control_system.php">				  				</a>             </li>	       </ul> </li>		 	   
	   
       <li>
		 <h3>
		 <a href="about.php">
	   关于我们		</h3>
         <ul class="bullets">
             <li><a href="about.php">公司简介</a></li>

			
             <li>
             <a href="ManagementTeam.php">管理团队</a>
             </li>
			
			 <li>
			 <a href="contact_us.php">
			联系我们				</a>
			</li>
			<!--
			<li>
				<a href="careers.php">
				   				</a>
             </li>
			 -->
         </ul>
       </li>
       
	   

      
     </ul>
     <div class="footer_border"></div>
        <div class="sign_wrap">
		 <h3 class="sign_in">
		 申请更新和报价</h3>
        <form id="subscribe" action="shoot.php" method="post" name="subscribe" class="ajax_contact"  data-errorsClass='subscribe-error' data-successClass='subscribe-success'>
              <ul>
                  <li class="envelope"></li>
				  <li><input type="text" name="email" placeholder="您的邮箱地址" required/></li>
				  <li><button class="submit" type="submit" onClick="_gaq.push(['_trackEvent', 'TRK', 'Subscribe', 'products']);">
		 订阅产品简讯</button></li>
              </ul>
              <div class="clear"></div>
         </form>
       </div>   
     <ul class="face_tube">
         <li><a href="https://www.facebook.com/AsteraLEDTechnology" target="_blank" class="facebook_group"></a></li>
         <li><a href="https://twitter.com/AsteraGlobal" target="_blank" class="twitter_group"></a></li>
         <li><a href="http://www.youtube.com/user/AsteraLED" target="_blank" class="youtube"></a></li>
     </ul>
  </div>
  
  <div class="black_strip">
       <div class="wrapper_960">
		 <p class="copyright">
		 © 2007-2014 Astera LED Technology.版权所有</p>
         <p class="muze_studio"><a href="http://www.muze-studio.co.il" target="_blank">UX Design | Web Design by Muze Studio</a></p>

		        </div>
  </div>
</footer>




<script type="text/javascript" src="js/jquery.stellar.min.js"></script>
<script src="js/jquery.bxslider.min.js"></script>
<script type="text/javascript">

$(document).ready(function() {
	
 
			  var slider2 = $('.slider2').bxSlider({
				controls: true,
		        auto: false,
		        speed: '1000',
				pager:false,
				});

	   if ($(window).width() > 1024 ) {
    //big screen, load this please 
                $.stellar({
				horizontalScrolling: false,
				verticalOffset: 40
		     	});
        }
   });

</script>
<script type="text/javascript" src="js/ajax_contact.js"></script>

</body>
</html>
