

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="wireless, lamps, controllers, event lighting,  lighting, architectural led lighting, deco lights, led controllers," />
  <meta name="description" content="Astera LED-Technology is a manufacturer of wireless LED lights and lighting controllers for event lighting and architectural lighting." />
  <link href="/favicon.ico" rel="shortcut icon" type="image/x-icon" />


<title>Astera LED Technology - Wireless LED Solutions for Event and Architectural Lighting - About us</title>
<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
<link href="jquery.bxslider.css" rel="stylesheet" />
<link rel="stylesheet" href="style.css" type="text/css">

<script>
var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42824105-1']);
  _gaq.push(['_trackPageview']);
  _gaq.push(['_trackPageLoadTime']);


(function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
	

</script>
</head>
<body>

<header class="gradient">
 <div class="wrapper_960" style="padding:0; width:960px;">
     <a href="index.php" class="asteraLogo"><img src="images/astera_logo.png" alt="Astera Led Lighting" title="Astera Led Lighting"></a>
      <div class="lang_wrap">
	  <a class="language">中文</a>
     </div>
     <ul class="navigation">
	 <li><a href="wireless.php" id="onlink">
	   无线</a></li>
	   <li><a href="architectural.php" >
	   建筑</a></li>

 		   <li><a href="about.php" >
	   关于我们</a></li>
	   <li><a href="contact_us.php" >
	   联系我们</a></li>
	        </ul>
 </div>  
</header>
<div class="lang_strip">
   <div class="wrapper_960">
      <ul>
         <li><a href="?lang=en">English</a></li>
         <li><a href="?lang=de">Deutsch</a></li>
		 <li><a href="?lang=es">Español</a></li>
         <li><a href="?lang=cn">中文</a></li>

		 
<!--
		 <li><a>French</a></li>
		 <li><a>Italien</a></li>
		 <li><a>Spanish</a></li>
-->
      </ul>
   </div>
 </div>


<script>
$(document).ready(function() {
	$(".language").click(function () {
		$(".lang_strip").slideToggle(500);
		return false;
	}); 
});
</script>

 
<div class="banner_crew" data-stellar-background-ratio="0.5">
    <div class="wrapper_960" style="height:100%;">
       <div class="title_middle">
          <h1>管理团队</h1>
       <!--   <p>With a talented and ambitious R&D team, a focused management team, and a global network of suppliers and partners, Astera is able to divide its competences between wireless event lighting and project-based architectural lighting.</p>-->
       </div>
    </div>
</div><!--end of banner crew-->

<div class="team_wrap">
     <div class="wrapper_960">
        <ul class="ourteam">
		
           <li>
              <div class="pic">
			  <!-- Removing the  class="grayscale" -->
                 <img src="images/team_pic/Norbert.png">
              </div>
              <p class="memberblock">
			 <span class="member_name">Norbert Ernst</span>
				<span class="member_title">执行总裁</span>
				<span class="member_title">德国</span>
				<span class="member_disc">Norbert把自己认作是一位在LED照明产业工作的电力工程师, 这也是Astera成为了产业里最好的原因.他仍然非常专注于产品改革和创新技术并兼顾公司运营策略,他是在背后推进Astera创新的主动力</span>            
				 </p>
           </li>
           
		
           <li>
              <div class="pic">
                 <img src="images/team_pic/Laura1.png">
              </div>
              <p class="memberblock">
			  <span class="member_name">Laura Zhang</span>
				<span class="member_title">总经理</span>
				<span class="member_title">中国</span>
				<span class="member_disc">Laura的职责是管理公司日常的运营.这包括有效计划, 分派, 协调, 人员配备, 决策, 管理公司的收入和支出来实现Astera的盈利可能</span>            
				 </p>
           </li>
           
		
           <li>
              <div class="pic">
                 <img src="images/team_pic/Sebastian3.png">
              </div>
               <p class="memberblock">
			  <span class="member_name">Sebastian Bückle</span>
				<span class="member_title">销售和市场总监</span>
				<span class="member_title">德国</span>
				<span class="member_disc">Sebastian的职责是Astera的市场营销计划和实施, 品牌定位, 扩大市场和协调销售团队, 他对Astera产品系列的知识和了解是前所未有的, 而且他常常出现在各种展览会上.他坚定地相信多倾听客户的需求是一定不会错的</span>            
				</p>
           </li>
           
		
           <li>
              <div class="pic">
                 <img src="images/team_pic/Balazs1.png">
              </div>
              <p class="memberblock">
			  <span class="member_name">Balazs Maar</span>
				<span class="member_title">总财务长</span>
				<span class="member_title">匈牙利</span>
				<span class="member_disc">Balazs的职责是公司业务的财务部分.紧密地和执行总裁一同工作,Balazs 报告财政的机会,包含年度财政结算,和决定预算状况</span>            
				</p>
           </li>
           		
           <li>
              <div class="pic">
                 <img src="images/team_pic/Hanan1.png">
              </div>
               <p class="memberblock">
			 <span class="member_name">Hanan Yariv</span>
				<span class="member_title">技术总监</span>
				<span class="member_title">以色列</span>
				<span class="member_disc">Hanan以往丰富的程序编制经验让他足以胜任我们的技术总监职位.Hanan的职责是管理我们的光学部门, 意味着所有领域的设计, 结构, 测试和调试我们所有的系统.Hanan对我们产品的激情影响着他的设计师团队, 同时维护和提高我们的AsteraTouch™技术</span>            
				 </p>
           </li>
           		
           <li>
              <div class="pic">
                 <img src="images/team_pic/Simon.png">
              </div>
               <p class="memberblock">
			   <span class="member_name">Simon Canins</span>
				<span class="member_title">R&D 总监</span>
				<span class="member_title">智利</span>
				<span class="member_disc">Simon负责管理和带领Astera R&D团队进行LED 新产品的研发和设计，为公司不断实现先进和创新的理念。在加入Astera公司之前，Simon是慕尼黑顶级夜店的灯光工程师，在LED灯光设计和控制方面拥有丰富的经验。他的经验和才能使Astera产品设计能满足客户的各种需求,  并令Astera的技术和产品一直走在LED行业的最前沿.</span>            
				</p>
           </li>
		   
		   <li>
              <div class="pic">
                 <img src="images/team_pic/Luis1.png">
              </div>
               <p class="memberblock">
			   <span class="member_name">Luis Arguello</span>
				<span class="member_title">运营经理</span>
				<span class="member_title">墨西哥</span>
				<span class="member_disc">Luis 是我们的运营经理,负责公司的综合管理和产品监督工作,工程和质量部门. Luis设定和管理加工和质量进度,落实细节保证我们的质量标准</span>            
				</p>
           </li>
           	
			

           
		   

        </ul>
     </div>
</div>
   

<footer>
  <div class="wrapper_960">
     <ul class="sitemap">
       <li>
	   <h3><a href="wireless.php">
	   活动照明灯具</a></h3>
         <ul class="bullets">
             <li>
			 <a href="wireless.php">
	   无线灯具</a>
             </li>
              <li>
			 <a href="products.php">
	   产品</a>
             </li>
              <li>
			 <a href="technology.php">
	   技术</a>
             </li>
              <li>
			 <a href="downloads.php">
	   客户支持&下载</a>
             </li>

         </ul>
       </li>
       <li>
	   <h3><a href="architectural.php">
	   建筑照明灯具</a></h3>
         <ul class="bullets">
             <li>
			 <a href="archchelsea.php">
	   现代时尚的零售照明灯具</a>
             </li>
              <li>
			 <a href="archgardens.php">
	   独特的吊灯</a>
             </li>
              <li>
			 <a href="archdj.php">
	   DJ专业灯具</a>
             </li>
              <li>
			 <a href="architsu.php">
	   餐饮照明</a>
             </li>
         </ul>
       </li>
	   
	   	    <li><h3>	<a href="green.php">  联系我们 </h3><ul class="bullets"><li><a href="green_bulbs.php"></a></li><li><a href="green_tubes.php"> </a></li><li>	<a href="green_street_light.php">				 				</a>             </li>			 			<li>				<a href="green_control_system.php">				  				</a>             </li>	       </ul> </li>		 	   
	   
       <li>
		 <h3>
		 <a href="about.php">
	   关于我们		</h3>
         <ul class="bullets">
             <li><a href="about.php">公司简介</a></li>

			
             <li>
             <a href="ManagementTeam.php">管理团队</a>
             </li>
			
			 <li>
			 <a href="contact_us.php">
			联系我们				</a>
			</li>
			<!--
			<li>
				<a href="careers.php">
				   				</a>
             </li>
			 -->
         </ul>
       </li>
       
	   

      
     </ul>
     <div class="footer_border"></div>
        <div class="sign_wrap">
		 <h3 class="sign_in">
		 申请更新和报价</h3>
        <form id="subscribe" action="shoot.php" method="post" name="subscribe" class="ajax_contact"  data-errorsClass='subscribe-error' data-successClass='subscribe-success'>
              <ul>
                  <li class="envelope"></li>
				  <li><input type="text" name="email" placeholder="您的邮箱地址" required/></li>
				  <li><button class="submit" type="submit" onClick="_gaq.push(['_trackEvent', 'TRK', 'Subscribe', 'ManagementTeam']);">
		 订阅产品简讯</button></li>
              </ul>
              <div class="clear"></div>
         </form>
       </div>   
     <ul class="face_tube">
         <li><a href="https://www.facebook.com/AsteraLEDTechnology" target="_blank" class="facebook_group"></a></li>
         <li><a href="https://twitter.com/AsteraGlobal" target="_blank" class="twitter_group"></a></li>
         <li><a href="http://www.youtube.com/user/AsteraLED" target="_blank" class="youtube"></a></li>
     </ul>
  </div>
  
  <div class="black_strip">
       <div class="wrapper_960">
		 <p class="copyright">
		 © 2007-2014 Astera LED Technology.版权所有</p>
         <p class="muze_studio"><a href="http://www.muze-studio.co.il" target="_blank">UX Design | Web Design by Muze Studio</a></p>

		        </div>
  </div>
</footer>



<script type="text/javascript" src="js/jquery.stellar.min.js"></script>
<script type="text/javascript">

$(document).ready(function() {
				
			//	$('.pic').hover(
			//	 function(){ $(this).children("img").removeClass('grayscale') },
			//	 function(){ $(this).children("img").addClass('grayscale') });
	
   
	   if ($(window).width() > 1024 ) {
    //big screen, load this please 
                $.stellar({
				horizontalScrolling: false,
				verticalOffset: 40
		     	});
        }
   });

</script>
<script type="text/javascript" src="js/ajax_contact.js"></script>

</body>
</html>
