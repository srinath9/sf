

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="wireless, lamps, controllers, event lighting,  lighting, architectural led lighting, deco lights, led controllers," />
  <meta name="description" content="Astera LED-Technology is a manufacturer of wireless LED lights and lighting controllers for event lighting and architectural lighting." />
  <link href="/favicon.ico" rel="shortcut icon" type="image/x-icon" />


<title>Astera LED Technology - Wireless LED Solutions for Event and Architectural Lighting - About us</title>
<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
<link href="jquery.bxslider.css" rel="stylesheet" />
<link rel="stylesheet" href="style.css" type="text/css">


<script>
var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42824105-1']);
  _gaq.push(['_trackPageview']);
  _gaq.push(['_trackPageLoadTime']);


(function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
	

</script>

</head>
<body class="bkg_fixed">


<header class="gradient">
 <div class="wrapper_960" style="padding:0; width:960px;">
     <a href="index.php" class="asteraLogo"><img src="images/astera_logo.png" alt="Astera Led Lighting" title="Astera Led Lighting"></a>
      <div class="lang_wrap">
	  <a class="language">English</a>
     </div>
     <ul class="navigation">
	 <li><a href="wireless.php" >
	   Wireless</a></li>
	   <li><a href="architectural.php" >
	   Architectural</a></li>

 <li><a href="green.php" >Green</a></li></a></li>		   <li><a href="about.php" id="onlink">
	   About</a></li>
	   <li><a href="contact_us.php" >
	   Contact</a></li>
	        </ul>
 </div>  
</header>
<div class="lang_strip">
   <div class="wrapper_960">
      <ul>
         <li><a href="?lang=en">English</a></li>
         <li><a href="?lang=de">Deutsch</a></li>
		 <li><a href="?lang=es">Español</a></li>
         <li><a href="?lang=cn">中文</a></li>

		 
<!--
		 <li><a>French</a></li>
		 <li><a>Italien</a></li>
		 <li><a>Spanish</a></li>
-->
      </ul>
   </div>
 </div>


<script>
$(document).ready(function() {
	$(".language").click(function () {
		$(".lang_strip").slideToggle(500);
		return false;
	}); 
});
</script>



<div class="banner_about" data-stellar-background-ratio="0.5">
    <div class="wrapper_960">
	<h1 class="about_title">
	Develop and diffuse<br />
    the culture of the light</h1>
    </div>
</div><!--end of banner wire-->

<a href="products.php" class="explore_btn fademe_in">EXPLORE PRODUCTS ></a>

<div class="welcome_strip">
         <div class="wrapper_960">
			  <h1 class="about_title">
			  Welcome to Astera</h1>
			  <p class="about_text">
			  
Astera are based in Kreis Bad Kreuznach, Germany and we design and manufacture wireless LED fixtures and specialist long-life LED lighting solutions. Our experienced and professional team works with event lighting companies, architects, engineers and lighting designers worldwide. Since 2007, Astera has been dedicated to revolutionizing the LED lighting industry through developing several outstanding wireless fixtures, light sources and controllers.
<br> <br>
We are a revolutionizing force in wireless lighting technology selling in many countries worldwide including the USA, the UK, Germany, Australia, Italy, Singapore, Israel and many others. The company focuses on innovative products that are thoughtfully designed to meet the real needs of professional customers.
 
			  </p>
			  
			 
				<a href="ManagementTeam.php">
					<img class="about_pic mangpic grayscale" src="images/team_pic/crew_pic.png">
				</a>
			<a href="ManagementTeam.php" class="crew_link">Management Team</a>
	 
	  
      <div class="clear"></div>
     </div><!--end of wrapper 960-->
</div><!--end of welcome strip-->

<div class="about_main">
       <div class="wrapper_960">
	   <h2 class="about_title">Award-winning Innovation</h2>
		   <p class="about_text">
		   
With a talented and ambitious R&D team, a focused management team, and a global network of suppliers and partners, Astera is able to divide its competences between wireless event lighting and project-based architectural lighting. We have produced innovative and useful wireless event lights as well as award-winning customized lighting for renowned global lighting designers.
<br>
<br>
		Our approach to LED lighting has always been to develop adaptable and innovative fixtures for use in a myriad of aesthetically pleasing ways. Our design philosophy is to create the next stage in the evolution of our industry, to push the boundaries of technologies and usability, and to manufacture products where quality is an expectation and the advancement in design astonishes all.
 
		   </p>
          <img class="about_pic" src="images/about/1.jpg">
    <div class="clear"></div>
    <div class="border2"></div>
       </div><!--end of wrapper_960-->
</div><!--end of about_main strip-->

<div class="about_standart">
  <div class="wrapper_960">
            <h2 class="about_title_right">German Standard Engineering</h2>
    <img class="about_pic_left" src="images/about/2.jpg">

	<p class="about_text_right">
	
Our flexibility in production and service provide an industry-leading mix of LED lighting design and engineering knowledge. The benefit of using Astera is having trust in the value of the product. Creating efficient lighting solutions, with compact designs and powerful features is the sole importance for us, and therefore customers can rely on our experience. We are constantly improving our range with intuitive, clever software, and a shift towards high-end LEDs and batteries.
<br><br>
The fact that we have such experience means that Astera can adapt the technology to meet new requirements, and we can do so with ease, means that Astera have produced hundreds of light products. We have our own manufacturing facility full of experienced engineers that work with longstanding suppliers to create a flexible and professional organizational culture to meet our customers’ needs. Astera maintains the highest German quality control standards and manufacturing precision built up over years of improvements.
	</p>
  </div><!--end of wrapper_960-->
</div><!--end of about_standart strip-->

<div id="open_airs">
   <div class="wrapper_960" style="height:600px;">
   <div class="clear"></div>
      <div id="box">
		<h3>
		Our Vision</h3>
		<p>
		
At Astera we believe in continuous improvement, constant innovation, honesty, customer service and protecting the environment. In 2013 and beyond, Astera plans to transform the lighting industry even further by adding a whole package of new features and designs to its already complete product range.
<br><br>
Our mission is:
<br><br>
<span style="font-weight:bold">To revolutionize LED lighting and showcase truly exceptional uses for light. We aim to increase the possibilities for event lighting, and create simple processes to deliver breathtaking event illumination.</span>
		</p>
       </div><!--end of box-->
   </div>
</div>


<div class="about_standart">
  <div class="wrapper_960">


	<p class="about_text_right">
	



    <div class="wrapper_960">
       <h2 class="about_title" style="margin-top:60px;">A Decade in the making</h2>
	   <p class="about_text">
In 2003, Norbert Ernst, an electrical engineering scholar from Germany, was commissioned to design and manufacture a rechargeable LED light display for brand advertisements Xellent Swiss Vodka and Smirnoff Ice. In 2004, Ernst produces the first LED wireless light completely controllable by a radio-frequency remote control. It was designed for use with cocktail tables, and it featured only white LEDs and contained a NiMH (Nickel-metal hybrid) battery. The first on/off controller via a single channel (443MHz) was also made. Astera was formed in 2007. Since then, Astera has revolutionized the event lighting market by launching the first wireless, battery-powered, RF-controlled light, and also the brightest and most compact spotlight, the only wireless pixel tube on the market, and the AsteraTouch™; the only tablet controller to be specifically designed for event lighting.
<br><br>
Today, Astera is a worldwide innovator with a comprehensive range of wireless event products and a professional and adaptable architectural division.
	   
	   </p>
       <img class="about_pic" src="images/about/7.jpg">
       <div class="clear"></div>
    </div>


	</p>
  </div><!--end of wrapper_960-->
</div><!--end of about_standart strip-->



<footer>
  <div class="wrapper_960">
     <ul class="sitemap">
       <li>
	   <h3><a href="wireless.php">
	   Event Lighting</a></h3>
         <ul class="bullets">
             <li>
			 <a href="wireless.php">
	   Wireless Lights </a>
             </li>
              <li>
			 <a href="products.php">
	   Products </a>
             </li>
              <li>
			 <a href="technology.php">
	   Technology</a>
             </li>
              <li>
			 <a href="downloads.php">
	   Support & Downloads</a>
             </li>

         </ul>
       </li>
       <li>
	   <h3><a href="architectural.php">
	   Architectural Lighting</a></h3>
         <ul class="bullets">
             <li>
			 <a href="archchelsea.php">
	   Modern Retail Lighting</a>
             </li>
              <li>
			 <a href="archgardens.php">
	   Unique Chandelier</a>
             </li>
              <li>
			 <a href="archdj.php">
	   Special DJ Lighting</a>
             </li>
              <li>
			 <a href="architsu.php">
	   Restaurant Illumination</a>
             </li>
         </ul>
       </li>
	   
	   	    <li><h3>	<a href="green.php">  Green Lighting </h3><ul class="bullets"><li><a href="green_bulbs.php">Bulbs</a></li><li><a href="green_tubes.php"> Tubes</a></li><li>	<a href="green_street_light.php">				 Street Lights				</a>             </li>			 			<li>				<a href="green_control_system.php">				  Control System				</a>             </li>	       </ul> </li>		 	   
	   
       <li>
		 <h3>
		 <a href="about.php">
	   About Us		</h3>
         <ul class="bullets">
             <li><a href="about.php">Company Profile</a></li>

			
             <li>
             <a href="ManagementTeam.php">Management Team</a>
             </li>
			
			 <li>
			 <a href="contact_us.php">
			Contact Us				</a>
			</li>
			<!--
			<li>
				<a href="careers.php">
				   				</a>
             </li>
			 -->
         </ul>
       </li>
       
	   

      
     </ul>
     <div class="footer_border"></div>
        <div class="sign_wrap">
		 <h3 class="sign_in">
		 SUBSCRIBE FOR UPDATES AND OFFERS</h3>
        <form id="subscribe" action="shoot.php" method="post" name="subscribe" class="ajax_contact"  data-errorsClass='subscribe-error' data-successClass='subscribe-success'>
              <ul>
                  <li class="envelope"></li>
				  <li><input type="text" name="email" placeholder="Your Email Address" required/></li>
				  <li><button class="submit" type="submit" onClick="_gaq.push(['_trackEvent', 'TRK', 'Subscribe', 'about']);">
		 SUBSCRIBE</button></li>
              </ul>
              <div class="clear"></div>
         </form>
       </div>   
     <ul class="face_tube">
         <li><a href="https://www.facebook.com/AsteraLEDTechnology" target="_blank" class="facebook_group"></a></li>
         <li><a href="https://twitter.com/AsteraGlobal" target="_blank" class="twitter_group"></a></li>
         <li><a href="http://www.youtube.com/user/AsteraLED" target="_blank" class="youtube"></a></li>
     </ul>
  </div>
  
  <div class="black_strip">
       <div class="wrapper_960">
		 <p class="copyright">
		 © 2007-2014 Astera LED Technology. All Rights reserved.</p>
         <p class="muze_studio"><a href="http://www.muze-studio.co.il" target="_blank">UX Design | Web Design by Muze Studio</a></p>

		 		 <p class="muze_studio"><a target="_blank" href="imprint.php">Imprint</a>&nbsp; | </p>
		        </div>
  </div>
</footer>


<script type="text/javascript" src="js/jquery.stellar.min.js"></script>
<script type="text/javascript">

   $(window).scroll(function(){
			  var pos = $(window).scrollTop();
			      target = $(".fademe_in");
				  
			  if (pos > 400){
				  target.fadeIn("slow");
			  } else {
				  target.fadeOut("slow");
			  }
			  return false;
		   });
		  
   $(document).ready(function() {	

   
   
	   if ($(window).width() > 1024 ) {
    //big screen, load this please 
                $.stellar({
				horizontalScrolling: false,
				verticalOffset: 40
		     	});
        }
		
		 
						$('.mangpic').hover(
				 function(){ $(this).removeClass('grayscale') },
				 function(){ $(this).addClass('grayscale') });
	
	
	
   });


</script>
<script type="text/javascript" src="js/ajax_contact.js"></script>
</body>
</html>
