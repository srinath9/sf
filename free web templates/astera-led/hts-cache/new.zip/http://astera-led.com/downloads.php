

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="wireless, lamps, controllers, event lighting,  lighting, architectural led lighting, deco lights, led controllers," />
  <meta name="description" content="Astera LED-Technology is a manufacturer of wireless LED lights and lighting controllers for event lighting and architectural lighting." />
  <link href="/favicon.ico" rel="shortcut icon" type="image/x-icon" />


<title>Astera LED Technology - Wireless LED Solutions for Event and Architectural Lighting - Downloads</title>
<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
<link href="jquery.bxslider.css" rel="stylesheet" />
<link rel="stylesheet" href="style.css" type="text/css">


<script>
var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42824105-1']);
  _gaq.push(['_trackPageview']);
  _gaq.push(['_trackPageLoadTime']);


(function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
	

</script>
</head>
<body>

<header class="gradient">
 <div class="wrapper_960" style="padding:0; width:960px;">
     <a href="index.php" class="asteraLogo"><img src="images/astera_logo.png" alt="Astera Led Lighting" title="Astera Led Lighting"></a>
      <div class="lang_wrap">
	  <a class="language">中文</a>
     </div>
     <ul class="navigation">
	 <li><a href="wireless.php" id="onlink">
	   无线</a></li>
	   <li><a href="architectural.php" >
	   建筑</a></li>

 		   <li><a href="about.php" >
	   关于我们</a></li>
	   <li><a href="contact_us.php" >
	   联系我们</a></li>
	        </ul>
 </div>  
</header>
<div class="lang_strip">
   <div class="wrapper_960">
      <ul>
         <li><a href="?lang=en">English</a></li>
         <li><a href="?lang=de">Deutsch</a></li>
		 <li><a href="?lang=es">Español</a></li>
         <li><a href="?lang=cn">中文</a></li>

		 
<!--
		 <li><a>French</a></li>
		 <li><a>Italien</a></li>
		 <li><a>Spanish</a></li>
-->
      </ul>
   </div>
 </div>


<script>
$(document).ready(function() {
	$(".language").click(function () {
		$(".lang_strip").slideToggle(500);
		return false;
	}); 
});
</script>





<!--Item Banner-->

<div class="support_banner" style="margin-top: 60px;">
  <div class="wrapper_960">
     <div class="item_details" style="width:530px;">
        <h1>支持</h1>
		<p>
		我们定期更新产品说明书、用户手册和软件，客户可以在这里下载到我们最新资料和软件。</p>
        <div class="socialBar" style="margin-top:0"></div>
     </div>
  </div>
</div>

<!--Item Details Banner-->

<div class="support_strip">
   <div class="wrapper_960" style="padding:1%;width:100%;">

      <div class="downloads_section">
          <a class="support_btn" style="background-color:#FF913E;width:70%;">手册</a>
		  <ol>
		    <li><a href="Downloads/Manuals/AL1 manual v4.0.20.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'MANUALS', 'AL1 manual']);">AL1 Pixel Tube</a></li>
			<li><a href="Downloads/Manuals/Lightdrop Quickstart Guide.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'MANUALS', 'Lightdrop Quickstart Guide']);">AL3 Lightdrop™ Quick Start Guide</a></li>
			<li><a href="Downloads/Manuals/AL6 manual v2.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'MANUALS', 'AL6 manual']);">AL6 Wireless Wallwasher</a></li>
			<li><a href="Downloads/Manuals/AL7 manual 3.8.3.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'MANUALS', 'AL7 manual']);">AL7-L Wireless Spotlight</a></li>
			<li><a href="Downloads/Manuals/al7-W manual 3.4.21.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'MANUALS', 'al7-W manual']);">AL7-X Water-Resistant Spotlight</a></li>
			<li><a href="Downloads/Manuals/ARC2 manual V3.4.21.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'MANUALS', 'ARC2 manual']);">ARC2 RF Remote Controller</a></li>
			<li><a href="Downloads/Manuals/ARC2 quick start guide v1.6.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'MANUALS', 'ARC2 quick start guide']);">ARC2 Quick Start Guide</a></li>
			<li><a href="Downloads/Manuals/AsteraTouch quick start guide v2.7.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'MANUALS', 'AsteraTouch quick start guide']);">ARC6 AsteraTouch™ Quick Start Guide</a></li>
			<li><a href="Downloads/Manuals/AsteraTouch Quick Start Guide DE v2.7.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'MANUALS', 'AsteraTouch Quick Start Guide DE']);">ARC6 AsteraTouch™ Quick Start Guide (DE)</a></li>
			<li><a href="Downloads/Manuals/ART3 manual 3.8.18.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'MANUALS', 'ART3 manual']);">ART3 Wireless DMX Transmitter</a></li>
			<li><a href="Downloads/Manuals/AC4 manual v3.4.12.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'MANUALS', 'AC4 manual']);">AC4 DMX Ethernet Gateway</a></li>
			<li><a href="Downloads/Manuals/AX10 Manual Online.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'MANUALS', 'AX10 manua online']);">AX10 SpotMax™ Manual On-line</a></li>
			
		  </ol>
      </div>


      <div class="downloads_section">
          <a class="support_btn" style="background-color:#FF913E;width:70%;">数据表</a>
		  <ol>
			  <li><a href="Downloads/Datasheets/Product Sheet AL1.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DATASHEETS', 'Product Sheet AL1']);">AL1 Pixel Tube</a></li>
			  <li><a href="Downloads/Datasheets/Product Sheet AL3-S.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DATASHEETS', 'Product Sheet AL3-S']);">AL3-S Mini Lightdrop™</a></li>
			  <li><a href="Downloads/Datasheets/Product Sheet AL3-M.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DATASHEETS', 'Product Sheet AL3-M']);">AL3-M Lightdrop™  </a></li>
			  <li><a href="Downloads/Datasheets/Product Sheet AL6.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DATASHEETS', 'Product Sheet AL6']);">AL6 Wireless Wallwasher</a></li>
			  <li><a href="Downloads/Datasheets/Product Sheet AL7-L.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DATASHEETS', 'Product Sheet AL7-L']);">AL7-L Wireless Spotlight</a></li>
			  <li><a href="Downloads/Datasheets/Product Sheet AL7-WXXL.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DATASHEETS', 'Product Sheet AL7-WXXL']);">AL7-X Water-Resistant Spotlight</a></li>
			  <li><a href="Downloads/Datasheets/Product Sheet AX10.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DATASHEETS', 'Product Sheet AX10']);">AX10 SpotMax™</a></li>
			  <li><a href="Downloads/Datasheets/Product Sheet ARC2.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DATASHEETS', 'Product Sheet ARC2']);">ARC2 RF Remote Controller</a></li>
			  <li><a href="Downloads/Datasheets/Product Sheet ARC6.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DATASHEETS', 'Product Sheet ARC6']);">ARC6 AsteraTouch™ </a></li>
			  <li><a href="Downloads/Datasheets/Product Sheet ART3.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DATASHEETS', 'Product Sheet ART3']);">ART3 Wireless DMX Transmitter</a></li>
			  <li><a href="Downloads/Datasheets/AC4 datasheet.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DATASHEETS', 'AC4 datasheet']);">AC4 DMX Ethernet Gateway</a></li>
			  <li><a href="Downloads/Datasheets/Product Sheet ART6.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DATASHEETS', 'Product Sheet ART6']);">ART6 AsteraBox™</a></li>
			  <li><a href="Downloads/Datasheets/Product Sheet Cases.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DATASHEETS', 'Product Sheet Charging Cases']);">Charging Cases</a></li>
			  			  <li><a href="Downloads/Datasheets/Product Sheet AX3.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DATASHEETS', 'Product Sheet AX3']);">AX3 Lightdrop™</a></li>
			  			  <li><a href="Downloads/Datasheets/Product Sheet AX7.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DATASHEETS', 'Product Sheet AX7']);">AX7 SpotLite™</a></li>
			  			  
			  
			  
			  
			  
		  </ol>
      </div>
	  

      <div class="downloads_section" style="margin-left:3%;width:20%;">
          <a class="support_btn">固件</a>
          <ol>
          <li>
             <a href="Downloads/Firmware/firmware updating process.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'FIRMWARE', 'firmware updating process']);">Firmware Updating Process</a>
          </li>
          <li>
             <a href="Downloads/Firmware/EU Bundle.zip" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'FIRMWARE', 'EU Bundle']);">Astera EU Firmware bundle – Apr, 2013</a>
          </li>
          <li>
             <a href="Downloads/Firmware/US Bundle.zip" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'FIRMWARE', 'US Bundle']);">Astera US Firmware bundle – Jul, 2013</a>
          </li>
          <li>
              <a href="Downloads/Firmware/Astera6.0.apk" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'FIRMWARE', 'latest']);">AsteraApp™ controller – v6.0 DISCONTINUED</a></br><span id="smallertext">
Notes:</br>
-This is an outdated release of the AsteraApp™. </br>
-All new downloads should be made via the <a style="text-decoration: underline;font-size:10px;" href="https://play.google.com/store/apps/details?id=com.asteraled.asteraapp">Play Store.</a></br>
-Only for Bluetooth-enabled Android 4.0.4 devices or newer.</br>
-Optimal performance on the following resolutions: 1024x600,
1280x800. Some functions may not work properly with other 
Resolutions.</br>
</span>
          </li>
		  </ol>
      </div>


      <div class="downloads_section"  style="margin-left:3%;width:20%;">
          <a class="support_btn">DMX 通道表</a>
          <ol>
			  <li>
			  <a href="Downloads/DMX Tables/DMX Table for AL1 MKIII.xlsx" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DMX TABLES', 'DMX Table for AL1 MKIII']);">AL1 Pixel Tube</a>
			  </li>
			  <li>
			  <a href="Downloads/DMX Tables/DMX Table for AL3S.xlsx" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DMX TABLES', 'DMX Table for AL3S']);">AL3-S Mini Lightdrop™</a>
			  </li>
			  <li>
			  <a href="Downloads/DMX Tables/DMX Table for AL3M.xlsx" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DMX TABLES', 'DMX Table for AL3M']);">AL3-M Lightdrop™   </a>
			  </li>
			  <li>
			  <a href="Downloads/DMX Tables/DMX Tables for AL6.rar" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DMX TABLES', 'DMX Tables for AL6']);">AL6 Wireless Wallwasher</a>
			  </li>
			  <li>
			  <a href="Downloads/DMX Tables/DMX Table for AL7L.xlsx" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DMX TABLES', 'DMX Table for AL7L']);">AL7-L Wireless Spotlight</a>
			  </li>
			  <li>
			  <a href="Downloads/DMX Tables/DMX Table for AL7-W.xlsx" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DMX TABLES', 'DMX Table for AL7-W']);">AL7-X Water-Resistant Spotlight</a>
			  </li>
			  <li>
			  <a href="Downloads/DMX Tables/DMX Table for AX10.xlsx" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DMX TABLES', 'DMX Table for AX10']);">AX10 SpotMax™</a>
			  </li>
			  <li>
			  <a href="Downloads/DMX Tables/DMX Table for AX10.xlsx" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'DMX TABLES', 'DMX Table for AX10']);">AX10 SpotMax™</a>
			  </li>
		  </ol>
      </div>




      <div class="downloads_section" style="margin-left:3%;width:20%;margin-top:-130px;">
          <a class="support_btn">其他</a>
		  <ol>
			  <li><a href="Downloads/Other/2014 Event Catalogue.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'OTHER', 'Astera Event Catalogue 2014']);">Wireless Product Catalog</a></li>
			  <li><a href="Downloads/Other/Architectural 2014 Catalogue.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'OTHER', 'Astera Architectural Catalog 2014']);">Architectural Projects Catalog</a></li>
			  <li><a href="Downloads/Other/Astera Product Warranty.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'OTHER', 'Astera Architectural Catalog 2014']);">Product Warranty</a></li>
			  <li><a href="Downloads/Other/Astera Sales Policy.pdf" target="_blank" onClick="_gaq.push(['_trackEvent', 'Downloads', 'OTHER', 'Astera Architectural Catalog 2014']);">Terms and Conditions</a></li>
			  

		  </ol>
      </div>
	  
	  
      
   </div>
</div>




<div style="margin-top:0;" class="support_banner">
  <div class="wrapper_960">
     <div class="item_details">
      <!--   <h1>FAQ</h1> -->
		<!-- <p>以下收集了一些常见问题和答案，供客户查阅。如果下面没有您问题的答案，请填写我们联系表格。 <a style="font-weight:bold;color:#333333;" href="contact_us.html">Contact Us page</a>.</p> -->
        <div style="margin-top:0" class="socialBar"></div>
     </div>
  </div>
</div>


<div class="faq">
    <div class="wrapper_960">
        
    </div><!--end wrapper-->
</div>


    

<footer>
  <div class="wrapper_960">
     <ul class="sitemap">
       <li>
	   <h3><a href="wireless.php">
	   活动照明灯具</a></h3>
         <ul class="bullets">
             <li>
			 <a href="wireless.php">
	   无线灯具</a>
             </li>
              <li>
			 <a href="products.php">
	   产品</a>
             </li>
              <li>
			 <a href="technology.php">
	   技术</a>
             </li>
              <li>
			 <a href="downloads.php">
	   客户支持&下载</a>
             </li>

         </ul>
       </li>
       <li>
	   <h3><a href="architectural.php">
	   建筑照明灯具</a></h3>
         <ul class="bullets">
             <li>
			 <a href="archchelsea.php">
	   现代时尚的零售照明灯具</a>
             </li>
              <li>
			 <a href="archgardens.php">
	   独特的吊灯</a>
             </li>
              <li>
			 <a href="archdj.php">
	   DJ专业灯具</a>
             </li>
              <li>
			 <a href="architsu.php">
	   餐饮照明</a>
             </li>
         </ul>
       </li>
	   
	   	    <li><h3>	<a href="green.php">  联系我们 </h3><ul class="bullets"><li><a href="green_bulbs.php"></a></li><li><a href="green_tubes.php"> </a></li><li>	<a href="green_street_light.php">				 				</a>             </li>			 			<li>				<a href="green_control_system.php">				  				</a>             </li>	       </ul> </li>		 	   
	   
       <li>
		 <h3>
		 <a href="about.php">
	   关于我们		</h3>
         <ul class="bullets">
             <li><a href="about.php">公司简介</a></li>

			
             <li>
             <a href="ManagementTeam.php">管理团队</a>
             </li>
			
			 <li>
			 <a href="contact_us.php">
			联系我们				</a>
			</li>
			<!--
			<li>
				<a href="careers.php">
				   				</a>
             </li>
			 -->
         </ul>
       </li>
       
	   

      
     </ul>
     <div class="footer_border"></div>
        <div class="sign_wrap">
		 <h3 class="sign_in">
		 申请更新和报价</h3>
        <form id="subscribe" action="shoot.php" method="post" name="subscribe" class="ajax_contact"  data-errorsClass='subscribe-error' data-successClass='subscribe-success'>
              <ul>
                  <li class="envelope"></li>
				  <li><input type="text" name="email" placeholder="您的邮箱地址" required/></li>
				  <li><button class="submit" type="submit" onClick="_gaq.push(['_trackEvent', 'TRK', 'Subscribe', 'downloads']);">
		 订阅产品简讯</button></li>
              </ul>
              <div class="clear"></div>
         </form>
       </div>   
     <ul class="face_tube">
         <li><a href="https://www.facebook.com/AsteraLEDTechnology" target="_blank" class="facebook_group"></a></li>
         <li><a href="https://twitter.com/AsteraGlobal" target="_blank" class="twitter_group"></a></li>
         <li><a href="http://www.youtube.com/user/AsteraLED" target="_blank" class="youtube"></a></li>
     </ul>
  </div>
  
  <div class="black_strip">
       <div class="wrapper_960">
		 <p class="copyright">
		 © 2007-2014 Astera LED Technology.版权所有</p>
         <p class="muze_studio"><a href="http://www.muze-studio.co.il" target="_blank">UX Design | Web Design by Muze Studio</a></p>

		        </div>
  </div>
</footer>



<script type="text/javascript">

        $(document).ready(function() {		
 
				 $(".answare").hide();
				//toggle the componenet with class msg_body
				$(".question").click(function(){
				
				     var $this = $(this);
				   $this.addClass("active").siblings().removeClass("active");
				   $this.next(".answare").slideToggle(500)
				   .siblings(".answare").slideUp(500)
				   return false;
				   
				});

				
});	

</script>
<script type="text/javascript" src="js/ajax_contact.js"></script>

</body>
</html>
