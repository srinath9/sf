

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="wireless, lamps, controllers, event lighting,  lighting, architectural led lighting, deco lights, led controllers," />
  <meta name="description" content="Astera LED-Technology is a manufacturer of wireless LED lights and lighting controllers for event lighting and architectural lighting." />
  <link href="/favicon.ico" rel="shortcut icon" type="image/x-icon" />


<title>Astera LED Technology - Wireless LED Solutions for Event and Architectural Lighting - Engineered in Germany</title>
<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
<link rel="stylesheet" href="style.css" type="text/css">

<script>
var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42824105-1']);
  _gaq.push(['_trackPageview']);
  _gaq.push(['_trackPageLoadTime']);


(function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
	

</script>
</head>
<body>



<header class="gradient">
 <div class="wrapper_960" style="padding:0; width:960px;">
     <a href="index.php" class="asteraLogo"><img src="images/astera_logo.png" alt="Astera Led Lighting" title="Astera Led Lighting"></a>
      <div class="lang_wrap">
	  <a class="language">English</a>
     </div>
     <ul class="navigation">
	 <li><a href="wireless.php" >
	   Wireless</a></li>
	   <li><a href="architectural.php" >
	   Architectural</a></li>

 <li><a href="green.php" >Green</a></li></a></li>		   <li><a href="about.php" >
	   About</a></li>
	   <li><a href="contact_us.php" >
	   Contact</a></li>
	        </ul>
 </div>  
</header>
<div class="lang_strip">
   <div class="wrapper_960">
      <ul>
         <li><a href="?lang=en">English</a></li>
         <li><a href="?lang=de">Deutsch</a></li>
		 <li><a href="?lang=es">Español</a></li>
         <li><a href="?lang=cn">中文</a></li>

		 
<!--
		 <li><a>French</a></li>
		 <li><a>Italien</a></li>
		 <li><a>Spanish</a></li>
-->
      </ul>
   </div>
 </div>


<script>
$(document).ready(function() {
	$(".language").click(function () {
		$(".lang_strip").slideToggle(500);
		return false;
	}); 
});
</script>


<div class="homebanner" data-stellar-background-ratio="0.5">
      <div class="wrapper_960" style="height:100%">
            <div class="title_middle_home">
				   <h1>
Pioneer of Light</h1>
				   <h2>
Powerful LED technology and unique control software combined with German engineering standards confirms Astera’s place as one of the leading innovators of cutting-edge lighting solutions.				   </h2>
                  <a class="explore_btn1">
                    <div class="explore_arrow"></div>
                 </a>
            </div>
      </div>
</div>

<div class="exploreStrip">
  <div class="wrapper_960">
     <div class="left">
				  <p>
Designed specifically for event and stage lighting professionals, our wireless event range combines state-of-the-art wireless technology with uniquely designed housings, branded components such as Cree LEDs and Samsung batteries, and an intuitive control system and easy-to-use control app.				  </p>
                <div class="socialBar">
                    <div class="facebook">
                      <div class="fb-like" data-href="http://www.astera-led.com/" data-send="ture" data-layout="button_count" data-width="120"data-show-faces="false" data-font="arial"></div>
                    </div>
                    <!--facebook_like-->
                    <div id="fb-root"></div>
                    <script>(function(d, s, id) {
                      var js, fjs = d.getElementsByTagName(s)[0];
                      if (d.getElementById(id)) return;
                      js = d.createElement(s); js.id = id;
                      js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
                      fjs.parentNode.insertBefore(js, fjs);
                    }(document, 'script', 'facebook-jssdk'));</script>
                    <!--facebook_like-->
                   <div class="twitter" data-size="small">
                      <a href="https://twitter.com/share" class="twitter-share-button" data-url="http://www.astera-led.com/" data-via="your_screen_name" data-lang="en">Tweet</a>
                   </div> 
                    <!--twitterbutton-->
                   <script>
				   !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
                   </script>
                   <!--twitterbutton-->
                   <div class="googleplus">
                   <div class="g-plusone" data-size="medium"></div>
                   </div>
                   <!--google+button-->
					<script type="text/javascript">
                    (function() {
                      var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
                      po.src = 'https://apis.google.com/js/plusone.js';
                      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
                    })();
                  </script>
                  <!--google+button-->
                </div><!--end of social bar-->
        </div>
        <div class="clear"></div>
  </div>
</div>
<div class="wirelessBanner">
          <div class="wrapper_960">
                     <a href="wireless.php" class="wireless_left">
                       <div class="wireless_logo"></div>
						<h2>
WIRELESS EVENT LIGHTING						</h2>
						<p>
Event lighting solutions with powerful, versatile wireless fixtures and intelligent, easy-to-use controllers, making us the most creative manufacturer of decorative light fixtures.						</p>
                     </a>
                    <div class="clear"></div>
                    <a href="wireless.php"class="right_arrow"></a>
          </div><!--End of wrapper_960-->
</div><!--End of wirelessbanner-->

<div class="architectureBanner">
            <div class="wrapper_960">
                      <a href="architectural.php" class="architecture_right">
                         <div class="architecture_logo"></div>
						<h2>
ARCHITECTURAL LIGHTING						</h2>
						<p>
With the finest German R&D, adaptable technology, and cost-effective solutions, Astera brings you advanced, custom-built lighting for your project ideas.						</p>
                       </a>
                      <div class="clear"></div>
                      <a href="architectural.php" class="left_arrow"></a>
            </div><!--End of wrapper_960-->
</div><!--End of architecture-->


 <div class="greenBanner">            <div class="wrapper_960">                      <a href="green.php" class="wireless_left">                         <div class="green_logo"></div>						<h2>GREEN LIGHTING						</h2>						<p>Energy efficient, long-lasting bulbs, tubes and street lights, producing cost-effective, environmentally-friendly light, with minimal-effort dimming and light control via automated wireless systems.						</p>                       </a>                      <div class="clear"></div>                      <a href="green.php" class="right_arrow"></a>            </div></div>

<script type="text/javascript" src="js/jquery.stellar.min.js"></script>
<script type="text/javascript">

        $(document).ready(function() {		
			 $('.explore_btn1').click(function(){
                   var destination =  $(".wirelessBanner").offset().top;
                  $('html, body').animate({ scrollTop: destination}, 800);
				  return false;
              });
		});
		
	    if ($(window).width() > 1024 ) { 
			$(function(){
			$.stellar({
				horizontalScrolling: false,
				verticalOffset: 40
			});
		});
}
</script>
</body>
</html>
