

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="wireless, lamps, controllers, event lighting,  lighting, architectural led lighting, deco lights, led controllers," />
  <meta name="description" content="Astera LED-Technology is a manufacturer of wireless LED lights and lighting controllers for event lighting and architectural lighting." />
  <link href="/favicon.ico" rel="shortcut icon" type="image/x-icon" />


<title>Astera LED Technology - Wireless LED Solutions for Event and Architectural Lighting - Contact Form</title>
  
<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
<link href="jquery.bxslider.css" rel="stylesheet" />
<link rel="stylesheet" href="style.css" type="text/css">

<script>
var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42824105-1']);
  _gaq.push(['_trackPageview']);
  _gaq.push(['_trackPageLoadTime']);

(function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
  

</script>

</head>
<body>

<header class="gradient">
 <div class="wrapper_960" style="padding:0; width:960px;">
     <a href="index.php" class="asteraLogo"><img src="images/astera_logo.png" alt="Astera Led Lighting" title="Astera Led Lighting"></a>
      <div class="lang_wrap">
	  <a class="language">English</a>
     </div>
     <ul class="navigation">
	 <li><a href="wireless.php" >
	   Wireless</a></li>
	   <li><a href="architectural.php" >
	   Architectural</a></li>

 <li><a href="green.php" >Green</a></li></a></li>		   <li><a href="about.php" >
	   About</a></li>
	   <li><a href="contact_us.php" id="onlink">
	   Contact</a></li>
	        </ul>
 </div>  
</header>
<div class="lang_strip">
   <div class="wrapper_960">
      <ul>
         <li><a href="?lang=en">English</a></li>
         <li><a href="?lang=de">Deutsch</a></li>
		 <li><a href="?lang=es">Español</a></li>
         <li><a href="?lang=cn">中文</a></li>

		 
<!--
		 <li><a>French</a></li>
		 <li><a>Italien</a></li>
		 <li><a>Spanish</a></li>
-->
      </ul>
   </div>
 </div>


<script>
$(document).ready(function() {
	$(".language").click(function () {
		$(".lang_strip").slideToggle(500);
		return false;
	}); 
});
</script>

 
<div class="banner_contact_us" data-stellar-background-ratio="0.5">
    <div class="wrapper_960" style="height:100%;">
       <div class="title_middle_contact">
	   <h1>Contact Us</h1>
       </div>
    </div>
</div><!--end of banner crew-->

<div id="main_office">
   <div class="wrapper_960">

   <h2 class="tech_title" style="margin-bottom:20px;"></h2>
       <ul class="astera_top_offices" style="padding-bottom:100px;">
         <li class="office_box">
            <ul>
			
               <li>
                 <h2 class="contact_title">Astera LED Technology GmbH</h2>
               </li>
               <li class="location">
				   <p>
				   Nahestrasse 68-70<br>
				   55593 Rüdesheim an der Nahe<br>
				   Kreis Bad Kreuznach<br>
					Germany
					</p>
               </li>
               

            </ul>
         </li><!--end of office box-->
		 
		 
		 <!--  Removing the US box for now
		  <li class="office_box">
            <ul>
			            </ul>
         </li><!--end of office box-->
         
		 
		 
         <li class="office_box">
            <ul>
			

               <li>
                 <h2 class="contact_title">Europe</h2>
               </li>
			   
				<li class="phone">
			    <p> Sales: +49 (0)671-92028292</p>
				<p>Support: +49 (0)671 92039525 (8am-6pm CET)</p>
               </li>
			   
               <li>
                 <h2 class="contact_title">North America</h2>
               </li>
			   
				<li class="phone">
                 <p>Sales: +1-718-838-9620 (8am-2pm EST)</p>
				 <p>Support: +1-774-283-0455 (8am-6pm EST)</p>

               </li>
			   


               <li>
                 <h2 class="contact_title">Rest of World</h2>
               </li>
			   
               <li class="phone waypoint1">
                 <p>Sales/Support: +86 755 28237295</p>
               </li>

  

            </ul>
         </li><!--end of office box-->
		   
       </ul><!--end of wholesalers offices-->
	   
	  

       

<ul class="astera_top_offices" style="float:right;padding-bottom:0px">
	 <li class="office_box">
	 For all enquiries relating to our wireless products and/or your architectural project ideas, please use the form below.	</li>
</ul>
	   
 <h4 class="message_title">
 Send us a message below :</h4>      
<form id="form" action="" method="post" name="contact_form" class="ajax_contact" data-errorsClass='contact-error' data-successClass='contact-success'>
    <ul>
        
        <li>
            <input type="hidden" name="via" value="contact" />
            <input type="text" name="fullname" placeholder="Full Name" class="requiredField" required/>
        </li>
        <li>
            <input type="email" name="email" placeholder="Email" class="requiredField" required/>
            <span class="form_hint">"name@something.com"</span>
        </li>
         <li>
		 <textarea name="message" placeholder="Message" cols="40" rows="6" class="requiredField"></textarea>
        </li>
		<li>
		

			<div style="margin-bottom:20px;">Where did you hear about us?</div>
			<select name="heardfrom" class="requiredField">
				<option></option>
				<option value="Search Engine">Search Engine</option>
				<option value="Exhibition">Exhibition</option>
				<option value="LinkedIn">LinkedIn</option>
				<option value="Facebook">Facebook</option>
				<option value="Television">Television</option>
				<option value="Friend/Colleague">Friend/Colleague</option>
				<option value="Other Advertising">Other Advertising</option>
				<option value="Other Website">Other Website</option>
				<option value="Other">Other</option>
			</select> 

		</li>
        <li>
			<button class="submit" type="submit" onClick="_gaq.push(['_trackEvent', 'TRK', 'Contact', 'Contactpage']);">
			SEND</button>
        </li>
     </ul>
</form>
       
   </div><!--end of wrapper-->
</div><!--end of main office-->
	
   
<div class="map">
   <div class="wrapper_960">
      <div class="coords"></div>
   </div><!--end of wrapper-->
   
   
</div><!--end of map-->


 <div id="wholesalers">
   <div class="wrapper_960">
      <h2 class="tech_title">Authorized Worldwide Dealers</h2>
       <ul class="astera_top_offices">
	   
	   
	   	   	       <li class="office_box">
            <ul>
               <li>
                 <h2 class="contact_title">USA                                                                    :</h2>
               </li>
               <li class="location">
                 <p>
Astera-LEDs     </br>
1022 North Milwaukee Ave   </br>
Libertyville, IL 60048           </br>
USA            </br>                                                     
                                                                   
				</p>
               </li>
			    <li class="phone">
                 <p>+1-407-956-5337</p>
               </li>
               <li class="website">
                  <a href="http://www.astera-leds.com" target="_blank" style="color:blue;"><p>www.astera-leds.com</p></a>
               </li>
            </ul>
         </li>	   	




		 <li class="office_box">
            <ul>
               <li>
                 <h2 class="contact_title">Australia & NZ:</h2>
               </li>
               <li class="location">
                 <p>
Shop Bluebottle   </br>                                             
43 Stawell Street       </br>                 
Melbourne, Victoria 3051           </br>                             
Australia                                                                
                                                                   
				</p>
               </li>
			    <li class="phone">
                 <p>+61 03 9329 0709</p>
               </li>
               <li class="website">
                  <a href="http://shop.bb3.net.au/shop/products/category/astera" target="_blank" style="color:blue;"><p>www.shopbb3.net.au</p></a>
               </li>
            </ul>
         </li><!--end of office box-->
		 
		 <!--
	   
	        <li class="office_box">
            <ul>
               <li>
                 <h2 class="contact_title">USA                                                                     :</h2>
               </li>
               <li class="location">
                 <p>
				 Shape Street</br>
                         42 N. Industry Park</br>
                                        Deer Park, NY 11729</br>
                                                                    USA
                                                                   
				</p>
               </li>
			    <li class="phone">
                 <p>+1 516-543-0822</p>
               </li>
               <li class="website">
                  <a href="http://www.shapestreet.com/wifi-led/" target="_blank" style="color:blue;"><p>www.shapestreet.com </p></a>
               </li>
            </ul>
         </li><!--end of office box-->
	   
	   
	   	   
	   	       <li class="office_box">
            <ul>
               <li>
                 <h2 class="contact_title">Scandinavia                                                                    :</h2>
               </li>
               <li class="location">
                 <p>
				 Dansk Mobilscene A/S</br>
				 Axel Kiers Vej 18H</br>
				 DK-8270 Højbjerg</br>
				 Denmark	

				 
				</p>
               </li>
			    <li class="phone">
                 <p>+45 70 22 70 85</p>
               </li>
               <li class="website">
                <a href="http://www.cablefreeled.com" target="_blank" style="color:blue;">  <p>www.cablefreeled.com </p></a>
               </li>
            </ul>
         </li><!--end of office box-->
		 
		 	   		 
	   	       <li class="office_box">
            <ul>
               <li>
                 <h2 class="contact_title">Spain                                                                   :</h2>
               </li>
               <li class="location">
                 <p>
				 Productions Grandslam</br>
                                       Passatge Toledo 11 - 08014</br>
                                            Barcelona, Spain
                                                                   
				</p>
               </li>
			    <li class="phone">
                 <p>+34 932 966 134</p>
               </li>
               <li class="website">
               <a href="http://www.astera-led.es" target="_blank" style="color:blue;">   <p>www.astera-led.es</p></a>
               </li>
            </ul>
         </li><!--end of office box-->
		 
			   
			    <li class="office_box">
            <ul>
               <li>
                 <h2 class="contact_title">Switzerland                                                                     :</h2>
               </li>
               <li class="location">
                 <p>
				 SystemTec</br>
St. Gallerstrasse 20</br>
8352 Elsau-Räterschen</br>
Switzerland
                                                                   
				</p>
               </li>
			    <li class="phone">
                 <p>+41 52 338 06 04</p>
               </li>
               <li class="website">
                  <a href="http://www.systemtec.ch" target="_blank" style="color:blue;"><p>www.systemtec.ch</p></a>
               </li>
            </ul>
         </li><!--end of office box-->
		 
		 
		 

		 	   
			  
		 

		 
		 	   
	   	      
		 
		 	   

		 
		 	   
	   	      
		 
		 
		  <li class="office_box">
            <ul>
               <li>
                 <h2 class="contact_title">Israel                                                                  :</h2>
               </li>
               <li class="location">
                 <p>
				 SWIS – Solar Wireless Lights Ltd.</br>
				Hata'puch 4                      </br>   
				Zichron Ya'ackov, 30900         </br>                      
				Israel                                                                     
				</p>
               </li>
			    <li class="phone">
                 <p>+972 525088848</p>
               </li>
               <li class="website">
                 <a href="http://www.solar-wireless.co.il" target="_blank" style="color:blue;"><p>www.solar-wireless.co.il</p></a>
				
               </li>
            </ul>
         </li><!--end of office box-->		 
		  <li class="office_box">
            <ul>
               <li>
                 <h2 class="contact_title">Poland                                                                   :</h2>
               </li>
               <li class="location">
                 <p>
				G&K Logistic </br> 
				ul. Glówna 4, </br> 
				Pawel Grzelecki </br> 
				03-113 Warszawa </br> 
				Poland
                      
				</p>
               </li>
			    <li class="phone">
                 <p>+48 222502566</p>
               </li>
               <li class="website">
                 <a href="http://www.astera-led.pl" target="_blank" style="color:blue;"><p>www.astera-led.pl</p></a>
				
               </li>
            </ul>
         </li><!--end of office box-->
		 
		 	   	       <li class="office_box">
            <ul>
               <li>
                 <h2 class="contact_title">Singapore                                                                     :</h2>
               </li>
               <li class="location">
                 <p>
				 Partex International          </br>                           
7 Jalan Kilang #01-01                         </br>              
Singapore 159407    
                                                                   
				</p>
               </li>
			    <li class="phone">
                 <p>+65 6295 1779                                                    </p>
               </li>
               <li class="website">
                <a href="http://www.airstar-light.com" target="_blank" style="color:blue;">  <p>www.airstar-light.com</p></a>
               </li>
            </ul>
         </li><!--end of office box-->
		 
		 
		 
		 	   
       </ul><!--end of wholesalers offices-->
 </div>      

</div>  



<footer>
  <div class="wrapper_960">
     <ul class="sitemap">
       <li>
	   <h3><a href="wireless.php">
	   Event Lighting</a></h3>
         <ul class="bullets">
             <li>
			 <a href="wireless.php">
	   Wireless Lights </a>
             </li>
              <li>
			 <a href="products.php">
	   Products </a>
             </li>
              <li>
			 <a href="technology.php">
	   Technology</a>
             </li>
              <li>
			 <a href="downloads.php">
	   Support & Downloads</a>
             </li>

         </ul>
       </li>
       <li>
	   <h3><a href="architectural.php">
	   Architectural Lighting</a></h3>
         <ul class="bullets">
             <li>
			 <a href="archchelsea.php">
	   Modern Retail Lighting</a>
             </li>
              <li>
			 <a href="archgardens.php">
	   Unique Chandelier</a>
             </li>
              <li>
			 <a href="archdj.php">
	   Special DJ Lighting</a>
             </li>
              <li>
			 <a href="architsu.php">
	   Restaurant Illumination</a>
             </li>
         </ul>
       </li>
	   
	   	    <li><h3>	<a href="green.php">  Green Lighting </h3><ul class="bullets"><li><a href="green_bulbs.php">Bulbs</a></li><li><a href="green_tubes.php"> Tubes</a></li><li>	<a href="green_street_light.php">				 Street Lights				</a>             </li>			 			<li>				<a href="green_control_system.php">				  Control System				</a>             </li>	       </ul> </li>		 	   
	   
       <li>
		 <h3>
		 <a href="about.php">
	   About Us		</h3>
         <ul class="bullets">
             <li><a href="about.php">Company Profile</a></li>

			
             <li>
             <a href="ManagementTeam.php">Management Team</a>
             </li>
			
			 <li>
			 <a href="contact_us.php">
			Contact Us				</a>
			</li>
			<!--
			<li>
				<a href="careers.php">
				   				</a>
             </li>
			 -->
         </ul>
       </li>
       
	   

      
     </ul>
     <div class="footer_border"></div>
        <div class="sign_wrap">
		 <h3 class="sign_in">
		 SUBSCRIBE FOR UPDATES AND OFFERS</h3>
        <form id="subscribe" action="shoot.php" method="post" name="subscribe" class="ajax_contact"  data-errorsClass='subscribe-error' data-successClass='subscribe-success'>
              <ul>
                  <li class="envelope"></li>
				  <li><input type="text" name="email" placeholder="Your Email Address" required/></li>
				  <li><button class="submit" type="submit" onClick="_gaq.push(['_trackEvent', 'TRK', 'Subscribe', 'contact_us']);">
		 SUBSCRIBE</button></li>
              </ul>
              <div class="clear"></div>
         </form>
       </div>   
     <ul class="face_tube">
         <li><a href="https://www.facebook.com/AsteraLEDTechnology" target="_blank" class="facebook_group"></a></li>
         <li><a href="https://twitter.com/AsteraGlobal" target="_blank" class="twitter_group"></a></li>
         <li><a href="http://www.youtube.com/user/AsteraLED" target="_blank" class="youtube"></a></li>
     </ul>
  </div>
  
  <div class="black_strip">
       <div class="wrapper_960">
		 <p class="copyright">
		 © 2007-2014 Astera LED Technology. All Rights reserved.</p>
         <p class="muze_studio"><a href="http://www.muze-studio.co.il" target="_blank">UX Design | Web Design by Muze Studio</a></p>

		 		 <p class="muze_studio"><a target="_blank" href="imprint.php">Imprint</a>&nbsp; | </p>
		        </div>
  </div>
</footer>


<script src="js/waypoints.min.js"></script>
<script type="text/javascript" src="js/jquery.stellar.min.js"></script>
<script type="text/javascript">

 $(document).ready(function() {		
   
	   if ($(window).width() > 1024 ) {
    //big screen, load this please 
                $.stellar({
				horizontalScrolling: false,
				verticalOffset: 40
		     	});
        }


	  
	    var coords =  $(".coords")
	  $('.waypoint1').waypoint(function() {
	
	   coords.animate({
		   top : "160px",
		   opacity:1
		   }, 400);
	  });
		
});

</script>

<script type="text/javascript" src="js/ajax_contact.js"></script>
</body>
</html>
