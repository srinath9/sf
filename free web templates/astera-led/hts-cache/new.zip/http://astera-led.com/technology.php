

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="wireless, lamps, controllers, event lighting,  lighting, architectural led lighting, deco lights, led controllers," />
  <meta name="description" content="Astera LED-Technology is a manufacturer of wireless LED lights and lighting controllers for event lighting and architectural lighting." />
  <link href="/favicon.ico" rel="shortcut icon" type="image/x-icon" />


<title>Astera LED Technology - Wireless LED Solutions for Event and Architectural Lighting - About us</title>
<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
<link href="jquery.bxslider.css" rel="stylesheet" />
<link rel="stylesheet" href="style.css" type="text/css">


<script>
var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42824105-1']);
  _gaq.push(['_trackPageview']);
  _gaq.push(['_trackPageLoadTime']);


(function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
	

</script>

</head>
<body class="bkg_fixed">


<header class="gradient">
 <div class="wrapper_960" style="padding:0; width:960px;">
     <a href="index.php" class="asteraLogo"><img src="images/astera_logo.png" alt="Astera Led Lighting" title="Astera Led Lighting"></a>
      <div class="lang_wrap">
	  <a class="language">中文</a>
     </div>
     <ul class="navigation">
	 <li><a href="wireless.php" id="onlink">
	   无线</a></li>
	   <li><a href="architectural.php" >
	   建筑</a></li>

 		   <li><a href="about.php" >
	   关于我们</a></li>
	   <li><a href="contact_us.php" >
	   联系我们</a></li>
	        </ul>
 </div>  
</header>
<div class="lang_strip">
   <div class="wrapper_960">
      <ul>
         <li><a href="?lang=en">English</a></li>
         <li><a href="?lang=de">Deutsch</a></li>
		 <li><a href="?lang=es">Español</a></li>
         <li><a href="?lang=cn">中文</a></li>

		 
<!--
		 <li><a>French</a></li>
		 <li><a>Italien</a></li>
		 <li><a>Spanish</a></li>
-->
      </ul>
   </div>
 </div>


<script>
$(document).ready(function() {
	$(".language").click(function () {
		$(".lang_strip").slideToggle(500);
		return false;
	}); 
});
</script>



<div class="banner_about" data-stellar-background-ratio="0.5">
    <div class="wrapper_960">
	<h1 class="about_title">
	 技术优势</h1>
    </div>
</div><!--end of banner wire-->

<a href="products.php" class="explore_btn fademe_in">搜索产品 ></a>






<div class="about_decade">





<!--tech-1-->


<div class="wrapper_960" id="open_air">
	   <h2 style="margin-top:60px;" class="about_title">
无线操作</h2>
	   <p class="about_text">

我们所有的LED灯具都具有无线接收功能和内置电池。它们无需电源布线，安装简单，是活动装饰照明、舞台灯光和其它临时环境照明的理想产品。我们的无线灯具是电池供电，这意味着安装时间短，节省人力从而降低成本。灯具现在采用的是锂-锰-镍-钴材料电池，它特点是性能稳定，安全性高，使用寿命长。目前我们在X系列产品进一步改进了电池，采用三星电池，这令灯具在红、绿、蓝混合模式下可持续工作8小时(只亮红灯可持续工作24小时)。
<br><br>
Astera射频无线平板控制器是为高效活动照明专门设计。它可以快捷地对灯具进行设定，控制，分组，混合任何颜色和保存复杂的颜色变幻模式。目前有三款遥控产品，从低端的入门版本到高端的触摸平板。这些遥控器的频率在868MHz波段左右(美规产品是~915MHz), 这提高了射频控制系统的能力，使产品能自动寻找最理想的频率。这意味着摇控器可以在远达300米远的距离内控制我们的灯具。

	   </p>
       <img class="about_pic" src="images/about/3.jpg">
	   
       <div class="clear"></div>
</div>







</div>





<footer>
  <div class="wrapper_960">
     <ul class="sitemap">
       <li>
	   <h3><a href="wireless.php">
	   活动照明灯具</a></h3>
         <ul class="bullets">
             <li>
			 <a href="wireless.php">
	   无线灯具</a>
             </li>
              <li>
			 <a href="products.php">
	   产品</a>
             </li>
              <li>
			 <a href="technology.php">
	   技术</a>
             </li>
              <li>
			 <a href="downloads.php">
	   客户支持&下载</a>
             </li>

         </ul>
       </li>
       <li>
	   <h3><a href="architectural.php">
	   建筑照明灯具</a></h3>
         <ul class="bullets">
             <li>
			 <a href="archchelsea.php">
	   现代时尚的零售照明灯具</a>
             </li>
              <li>
			 <a href="archgardens.php">
	   独特的吊灯</a>
             </li>
              <li>
			 <a href="archdj.php">
	   DJ专业灯具</a>
             </li>
              <li>
			 <a href="architsu.php">
	   餐饮照明</a>
             </li>
         </ul>
       </li>
	   
	   	    <li><h3>	<a href="green.php">  联系我们 </h3><ul class="bullets"><li><a href="green_bulbs.php"></a></li><li><a href="green_tubes.php"> </a></li><li>	<a href="green_street_light.php">				 				</a>             </li>			 			<li>				<a href="green_control_system.php">				  				</a>             </li>	       </ul> </li>		 	   
	   
       <li>
		 <h3>
		 <a href="about.php">
	   关于我们		</h3>
         <ul class="bullets">
             <li><a href="about.php">公司简介</a></li>

			
             <li>
             <a href="ManagementTeam.php">管理团队</a>
             </li>
			
			 <li>
			 <a href="contact_us.php">
			联系我们				</a>
			</li>
			<!--
			<li>
				<a href="careers.php">
				   				</a>
             </li>
			 -->
         </ul>
       </li>
       
	   

      
     </ul>
     <div class="footer_border"></div>
        <div class="sign_wrap">
		 <h3 class="sign_in">
		 申请更新和报价</h3>
        <form id="subscribe" action="shoot.php" method="post" name="subscribe" class="ajax_contact"  data-errorsClass='subscribe-error' data-successClass='subscribe-success'>
              <ul>
                  <li class="envelope"></li>
				  <li><input type="text" name="email" placeholder="您的邮箱地址" required/></li>
				  <li><button class="submit" type="submit" onClick="_gaq.push(['_trackEvent', 'TRK', 'Subscribe', 'technology']);">
		 订阅产品简讯</button></li>
              </ul>
              <div class="clear"></div>
         </form>
       </div>   
     <ul class="face_tube">
         <li><a href="https://www.facebook.com/AsteraLEDTechnology" target="_blank" class="facebook_group"></a></li>
         <li><a href="https://twitter.com/AsteraGlobal" target="_blank" class="twitter_group"></a></li>
         <li><a href="http://www.youtube.com/user/AsteraLED" target="_blank" class="youtube"></a></li>
     </ul>
  </div>
  
  <div class="black_strip">
       <div class="wrapper_960">
		 <p class="copyright">
		 © 2007-2014 Astera LED Technology.版权所有</p>
         <p class="muze_studio"><a href="http://www.muze-studio.co.il" target="_blank">UX Design | Web Design by Muze Studio</a></p>

		        </div>
  </div>
</footer>


<script type="text/javascript" src="js/jquery.stellar.min.js"></script>
<script type="text/javascript">

   $(window).scroll(function(){
			  var pos = $(window).scrollTop();
			      target = $(".fademe_in");
				  
			  if (pos > 400){
				  target.fadeIn("slow");
			  } else {
				  target.fadeOut("slow");
			  }
			  return false;
		   });
		  
   $(document).ready(function() {	

   
   
	   if ($(window).width() > 1024 ) {
    //big screen, load this please 
                $.stellar({
				horizontalScrolling: false,
				verticalOffset: 40
		     	});
        }
		
		 
						$('.mangpic').hover(
				 function(){ $(this).removeClass('grayscale') },
				 function(){ $(this).addClass('grayscale') });
	
	
	
   });


</script>
<script type="text/javascript" src="js/ajax_contact.js"></script>
</body>
</html>
