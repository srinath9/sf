

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="wireless, lamps, controllers, event lighting,  lighting, architectural led lighting, deco lights, led controllers," />
  <meta name="description" content="Astera LED-Technology is a manufacturer of wireless LED lights and lighting controllers for event lighting and architectural lighting." />
  <link href="/favicon.ico" rel="shortcut icon" type="image/x-icon" />


<title>Astera LED Technology - Wireless LED Solutions for Event and Architectural Lighting - Architecture SONG, Kings road</title>
<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
<!--<script type="text/javascript" src="js/jquery.fitvids.js"></script>-->
<link href="jquery.bxslider.css" rel="stylesheet" />
<link rel="stylesheet" href="style.css" type="text/css">
<link rel="stylesheet" type="text/css" href="source/jquery.fancybox.css" media="screen" />


<script>
var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42824105-1']);
  _gaq.push(['_trackPageview']);
  _gaq.push(['_trackPageLoadTime']);


(function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
	
	
</script>

</head>
<body>

<header class="gradient">
 <div class="wrapper_960" style="padding:0; width:960px;">
     <a href="index.php" class="asteraLogo"><img src="images/astera_logo.png" alt="Astera Led Lighting" title="Astera Led Lighting"></a>
      <div class="lang_wrap">
	  <a class="language">English</a>
     </div>
     <ul class="navigation">
	 <li><a href="wireless.php" >
	   Wireless</a></li>
	   <li><a href="architectural.php" id="onlink">
	   Architectural</a></li>

 <li><a href="green.php" >Green</a></li></a></li>		   <li><a href="about.php" >
	   About</a></li>
	   <li><a href="contact_us.php" >
	   Contact</a></li>
	        </ul>
 </div>  
</header>
<div class="lang_strip">
   <div class="wrapper_960">
      <ul>
         <li><a href="?lang=en">English</a></li>
         <li><a href="?lang=de">Deutsch</a></li>
		 <li><a href="?lang=es">Español</a></li>
         <li><a href="?lang=cn">中文</a></li>

		 
<!--
		 <li><a>French</a></li>
		 <li><a>Italien</a></li>
		 <li><a>Spanish</a></li>
-->
      </ul>
   </div>
 </div>


<script>
$(document).ready(function() {
	$(".language").click(function () {
		$(".lang_strip").slideToggle(500);
		return false;
	}); 
});
</script>




<div class="project_nav">
   <div class="wrapper_960">
    <ul class="project_navigation">
	<li><a href="architectural.php" id="onlink">Overview</a></li>
       <li><a href="archchelsea.php" >SNOG Chelsea</a></li>
       <li><a href="archgardens.php" >Gardens by the Bay</a></li>
       <li><a href="archdj.php" >DJ Light</a></li>
       <li><a href="architsu.php" >Itsu Sushi</a></li>
       <li><a href="archlure.php" >Lure Hollywood</a></li>
       <li><a href="archbush.php" >SNOG Westfield</a></li>
       <li><a href="archsoho.php" >SNOG Soho</a></li>
     </ul>
   </div> 
 </div>



<div class="project_wrapper">
       <div class="slider_wrapper"> 

 <ul class="bxslider">
              <li>
				 <div class="content">
					 <h3>
					 World-class Chandeliers</h3>
				 </div>
                 <img src="images/arch/Overview/1.jpg" title="world-class chandeliers">
              </li>
              <li>
				 <div class="content">
					 <h3>
					 Eye-catching Restaurant Illumination</h3>
				 </div>
                 <img src="images/arch/Overview/2.jpg" title="Eye-Catching Restaurant Illumination">
              </li>
              <li>
				 <div class="content">
					 <h3>
					 Unique Customized Setups</h3>

				 </div>
                 <img src="images/arch/Overview/3.jpg" title="Unique Customized Setups">
              </li>
              <li>
				 <div class="content">
					 <h3>
					 Modern Retail Lighting</h3>

				 </div>
                 <img src="images/arch/Overview/4.jpg" title="Modern Retail Lighting">
              </li>
              <li>
				 <div class="content">
					 <h3>
					 Decorative Nightclub Lighting</h3>
				 </div>
                 <img src="images/arch/Overview/5.jpg" title="Decorative nightclub Lighting">
              </li>
              <li>
				 <div class="content">
					 <h3>
					 Mesmerising Illustrations</h3>

				 </div>
                 <img src="images/arch/Overview/6.jpg" title="Mesmerising Installations">
              </li>
              <li>
				 <div class="content">
					 <h3>
					 Architectural Lighting					</h3>
				 </div>
                 <img src="images/arch/Overview/7.jpg" title="Architectural Lighting">
              </li>
              <!-- 

			  This is the video one - removed for now.
			  <li>
              <iframe width="1600px" height="600px"  src="http://www.youtube.com/embed/C3M6u1DO25I" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
              </li> 
			  
			  -->
			  
			  <!-- 
			  for embedding the video you must : 
			  <script src="/js/plugins/jquery.fitvids.js"></script> must be included in the <head>
				after the jQuery library, and before the jquery.bxslider.js file. See the source code
				of this page for an example. 
				
				-->
        </ul>

  </div><!--End of slider wrapper-->
</div><!--End of project wrapper-->

<div class="archi_text">
   <div class="wrapper_960">
     <div class="socialBar" style="margin-top:20px;">
                    <div class="facebook">
                      <div class="fb-like" data-href="http://www.astera-led.com/architectural.php" data-send="true" data-layout="button_count" data-width="120" data-show-faces="false" data-font="arial"></div>
                    </div>
                    <!--facebook_like-->
                    <div id="fb-root"></div>
                    <script>(function(d, s, id) {
                      var js, fjs = d.getElementsByTagName(s)[0];
                      if (d.getElementById(id)) return;
                      js = d.createElement(s); js.id = id;
                      js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
                      fjs.parentNode.insertBefore(js, fjs);
                    }(document, 'script', 'facebook-jssdk'));</script>
                    <!--facebook_like-->
                   <div class="twitter" data-size="small">
                      <a href="https://twitter.com/share" class="twitter-share-button" data-url="http://www.astera-led.com/architectural.php" data-via="your_screen_name" data-lang="en">Tweet</a>
                   </div> 
                    <!--twitterbutton-->
                   <script>
				   !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
                   </script>
                   <!--twitterbutton-->
                   <div class="googleplus">
                   <div class="g-plusone" data-size="medium"></div>
                   </div>
                   <!--google+button-->
					<script type="text/javascript">
                    (function() {
                      var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
                      po.src = 'https://apis.google.com/js/plusone.js';
                      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
                    })();
                  </script>
                  <!--google+button-->
                </div><!--end of social bar-->
     <div class="about_project">
	 



<h2>Your project, from conception to completion</h2>
<p>Astera is proud in its ability to take your original and unique idea and transform that into a world-leading and eye-catching visual experience. We have a team of experienced engineers and lighting specialists that can take your vision from conception to completion. From the creative stages where we recommend the most suitable system and aesthetic to best complement your vision, to a full post-installation service, we serve your expectations through every stage of the project, and our industry-leading project management team will be available to assist you every step of the way.</p>

<br>

<h2>Offering comprehensive system integration</h2>
<p>The benefit of Astera’s architectural range is in its adaptability and its proven and expressive uses for LED fixtures. Astera is able to adapt any and all of its architectural technologies to fit with or into any conceivable project or design. With a vast and experienced research and development team, Astera has the knowledge and experience to manufacture architectural lighting for any project. We specialize in retail and commercial decorative lighting, but we are always seeking new and inventive lighting projects. </p>
<br>
<p>Many of our solutions, especially our chandeliers, are one-of-a-kind and very sought after eye-catchers with our clients. All of our range is fully customizable and we look forward to providing you with our advanced LED solutions.</p>

     </div>
     <div class="border3" style="margin-bottom:20px;"></div>
      <!--<a href="#" class="btn_left" style="color:#FF913E;">< PREVIOUS PROJECT</a>-->
	  <a href="archchelsea.php" class="btn_right" style="color:#FF913E;">
	  NEXT PROJECT >
</a>
   </div>
</div><!--End of archi_text-->



<footer>
  <div class="wrapper_960">
     <ul class="sitemap">
       <li>
	   <h3><a href="wireless.php">
	   Event Lighting</a></h3>
         <ul class="bullets">
             <li>
			 <a href="wireless.php">
	   Wireless Lights </a>
             </li>
              <li>
			 <a href="products.php">
	   Products </a>
             </li>
              <li>
			 <a href="technology.php">
	   Technology</a>
             </li>
              <li>
			 <a href="downloads.php">
	   Support & Downloads</a>
             </li>

         </ul>
       </li>
       <li>
	   <h3><a href="architectural.php">
	   Architectural Lighting</a></h3>
         <ul class="bullets">
             <li>
			 <a href="archchelsea.php">
	   Modern Retail Lighting</a>
             </li>
              <li>
			 <a href="archgardens.php">
	   Unique Chandelier</a>
             </li>
              <li>
			 <a href="archdj.php">
	   Special DJ Lighting</a>
             </li>
              <li>
			 <a href="architsu.php">
	   Restaurant Illumination</a>
             </li>
         </ul>
       </li>
	   
	   	    <li><h3>	<a href="green.php">  Green Lighting </h3><ul class="bullets"><li><a href="green_bulbs.php">Bulbs</a></li><li><a href="green_tubes.php"> Tubes</a></li><li>	<a href="green_street_light.php">				 Street Lights				</a>             </li>			 			<li>				<a href="green_control_system.php">				  Control System				</a>             </li>	       </ul> </li>		 	   
	   
       <li>
		 <h3>
		 <a href="about.php">
	   About Us		</h3>
         <ul class="bullets">
             <li><a href="about.php">Company Profile</a></li>

			
             <li>
             <a href="ManagementTeam.php">Management Team</a>
             </li>
			
			 <li>
			 <a href="contact_us.php">
			Contact Us				</a>
			</li>
			<!--
			<li>
				<a href="careers.php">
				   				</a>
             </li>
			 -->
         </ul>
       </li>
       
	   

      
     </ul>
     <div class="footer_border"></div>
        <div class="sign_wrap">
		 <h3 class="sign_in">
		 SUBSCRIBE FOR UPDATES AND OFFERS</h3>
        <form id="subscribe" action="shoot.php" method="post" name="subscribe" class="ajax_contact"  data-errorsClass='subscribe-error' data-successClass='subscribe-success'>
              <ul>
                  <li class="envelope"></li>
				  <li><input type="text" name="email" placeholder="Your Email Address" required/></li>
				  <li><button class="submit" type="submit" onClick="_gaq.push(['_trackEvent', 'TRK', 'Subscribe', 'architectural']);">
		 SUBSCRIBE</button></li>
              </ul>
              <div class="clear"></div>
         </form>
       </div>   
     <ul class="face_tube">
         <li><a href="https://www.facebook.com/AsteraLEDTechnology" target="_blank" class="facebook_group"></a></li>
         <li><a href="https://twitter.com/AsteraGlobal" target="_blank" class="twitter_group"></a></li>
         <li><a href="http://www.youtube.com/user/AsteraLED" target="_blank" class="youtube"></a></li>
     </ul>
  </div>
  
  <div class="black_strip">
       <div class="wrapper_960">
		 <p class="copyright">
		 © 2007-2014 Astera LED Technology. All Rights reserved.</p>
         <p class="muze_studio"><a href="http://www.muze-studio.co.il" target="_blank">UX Design | Web Design by Muze Studio</a></p>

		 		 <p class="muze_studio"><a target="_blank" href="imprint.php">Imprint</a>&nbsp; | </p>
		        </div>
  </div>
</footer>


<script type="text/javascript" src="source/jquery.fancybox.js"></script>
<script type="text/javascript" src="source/helpers/jquery.fancybox-media.js?v=1.0.5"></script>
<script src="js/jquery.bxslider.min.js"></script>
<script type="text/javascript">

        $(document).ready(function() {		
 
			  var slider = $('.bxslider').bxSlider({
				infiniteLoop: true, 
		        auto: 'true',
		        speed: '1000',
				pause: 7000,
				pager:false,

				});
	

				$(".thumb-link").click(function(e)
				{
				 e.preventDefault();
				
				 slider.goToSlide($(this).attr("data-thumb"));
				});
				
				$('.thumb-link').hover(
				 function(){ $(this).children("img").removeClass('grayscale') },
				 function(){ $(this).children("img").addClass('grayscale') });
	
	
		  
		  $(window).scroll(function(){
			  var pos = $(window).scrollTop();
			      target = $(".fademe");
				  
			  if (pos > 10){
				  target.stop(true, true).fadeOut("slow" );
			  } else {
				  target.stop(true, true).fadeIn("slow");
			  }
		   });


		$('#data_item_come_up').fancybox({
		openEffect  : 'none',
		closeEffect : 'none',
		helpers : {
			media : {},
			 overlay: {
                    locked: false
                }
		}
		});
		  
	
    });
	
</script>
<script type="text/javascript" src="js/ajax_contact.js"></script>
</body>
</html>
