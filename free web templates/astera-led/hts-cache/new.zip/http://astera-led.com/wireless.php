

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="wireless, lamps, controllers, event lighting,  lighting, architectural led lighting, deco lights, led controllers," />
  <meta name="description" content="Astera LED-Technology is a manufacturer of wireless LED lights and lighting controllers for event lighting and architectural lighting." />
  <link href="/favicon.ico" rel="shortcut icon" type="image/x-icon" />


<title>Astera LED Technology - Wireless LED Solutions for Event and Architectural Lighting - Wireless LED Lighting</title>
  
<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
<link href="jquery.bxslider.css" rel="stylesheet" />
<link rel="stylesheet" href="style.css" type="text/css">
<link rel="stylesheet" type="text/css" href="source/jquery.fancybox.css" media="screen" />



<script>
var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42824105-1']);
  _gaq.push(['_trackPageview']);
  _gaq.push(['_trackPageLoadTime']);


(function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
	

</script>

</head>
<body>

<header class="gradient">
 <div class="wrapper_960" style="padding:0; width:960px;">
     <a href="index.php" class="asteraLogo"><img src="images/astera_logo.png" alt="Astera Led Lighting" title="Astera Led Lighting"></a>
      <div class="lang_wrap">
	  <a class="language">English</a>
     </div>
     <ul class="navigation">
	 <li><a href="wireless.php" id="onlink">
	   Wireless</a></li>
	   <li><a href="architectural.php" >
	   Architectural</a></li>

 <li><a href="green.php" >Green</a></li></a></li>		   <li><a href="about.php" >
	   About</a></li>
	   <li><a href="contact_us.php" >
	   Contact</a></li>
	        </ul>
 </div>  
</header>
<div class="lang_strip">
   <div class="wrapper_960">
      <ul>
         <li><a href="?lang=en">English</a></li>
         <li><a href="?lang=de">Deutsch</a></li>
		 <li><a href="?lang=es">Español</a></li>
         <li><a href="?lang=cn">中文</a></li>

		 
<!--
		 <li><a>French</a></li>
		 <li><a>Italien</a></li>
		 <li><a>Spanish</a></li>
-->
      </ul>
   </div>
 </div>


<script>
$(document).ready(function() {
	$(".language").click(function () {
		$(".lang_strip").slideToggle(500);
		return false;
	}); 
});
</script>


<div class="banner wire" data-stellar-background-ratio="0.5">
    <div class="wrapper_960">
	  <h1 class="wireless_title" style="font-weight:bold;text-shadow: 2px 2px 8px #000000;">
	  Wireless Event Lights</h1>
	  <h2 class="wireless_sub_title">
	  Effective, portable, remote-controlled event lighting with the most advanced technology on the market</h2>
    </div>
</div><!--end of banner wire-->
<a href="products.php" class="explore_btn fademe_in">EXPLORE PRODUCTS ></a>
<div class="wrapper_960">
  <h2 class="wireless_title">
	  Next generation wireless event lights</h2>
  <ul class="top_wireless_products">
    <li>
    <a href="pax10.php">
      <div class="hover_it">
         <div class="item_btn"> <p class="item_explore">
		   <span class="enter">
   ultra-bright for <br>outdoor lighting
</span></p>
         </div>
      </div>
      <div class="item_image"><img width="215" height="215" src="images/product_overview/SpotMax.png"></div>
            <div class="item_name" style="z-index:5;">SpotMax™</div>
      </a>
    </li>
	  
    <li>
    <a href="part6.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
		   <span class="enter">
   advanced controller <br>designed for event lighting
</span></p>
         </div>
      </div>
      <div class="item_image"><img width="215" height="215" src="images/product_overview/AsteraBox-overview.png"></div>
	  <div class="item_name" style="z-index:5;">AsteraBox™</div>
      </a>
    </li>

    <li>
    <a href="pax3.php">
      <div class="hover_it">
         <div class="item_btn">
           <p class="item_explore">
		   <span class="enter">
   multi-use spotlight <br>for effective lighting
</span></p>

         </div>
      </div>
      <div class="item_image"><img width="215" height="215" src="images/product_overview/Lightdropx.png"></div>
            <div class="item_name" style="z-index:5;">Lightdrop™</div>
      </a>
    </li>

	<li>
	
	
			<div class="wrapper">
				<a href="products.php" class="wire_btn">
				  <span class="wire_hover"></span>
				  <span class="wire_icon"></span>
				  <span class="explore_more">
				  MORE PRODUCTS</span>
				</a>
			</div>
	
	
	
				
	
	</li>
	
	
  </ul>

  
  
  <h2 class="wireless_title">
	  Why choose Astera?</h2>

  <ul class="best_badge">
    <li>
	<div class="badge_img"><a href="products.php"><img src="images/icon-badg.png"></a></div>
	 <h3>
	  High-end Components</h3>
	 <p>
	  Astera uses high-end components such as Cree LEDs, Samsung batteries, Lumen Radio CRMX, Neutrik connectors etc. for their products.</p>
    </li>
    <li>
	<div class="badge_img"><a href="technology.php"><img src="images/icon-screwdriver.png"></a></div>
	 <h3>
	  Easy Control</h3>
	 <p>
	  The AsteraApp™ lets you create complex effects and send them to individual lights or groups of lights within minutes. Lighting control has never been easier and more efficient.</p>
    </li>
    <li>
	<div class="badge_img"><a href="products.php"><img src="images/icon-2arrows.png"></a></div>
	 <h3>
	  Clever Housings</h3>
	 <p>
	  Unlike other manufacturers, Astera produces compact and well-designed spotlights that are waterproof and have clever features for daily handling</p>

    </li>
    <li>
	<div class="badge_img"><a href="technology.php"><img src="images/icon-lightball.png"></a></div>
	 <h3>
	  Advanced Technology</h3>
	 <p>
	  Astera has 10 years’ experience with wireless lights and has industry-leading features such as TruColor™ Calibration and smart battery management.</p>

    </li>
  </ul>
 <div class="clear"></div>
</div><!--end of wrapper_960-->

<div class="banner_bottom"></div>


<div class="wrapper_960">
  <div class="exhibition" style="background-image: none;">
	  <a href="https://vimeo.com/78701158" class="top_video" style="float:none;margin:0 auto;"></a>
  </div>
  
  <div class="news">
     <div class="led">
         <div class="article1">
			 <div class="newslogo"><a href="http://www.plsn.com/product-news/13367-astera-led-technologys-asterabox.html" target="_blank"><img src="images/news/plsn1.png"></a></div>
			<p> 12/05/14: Astera launches AsteraApp™ and AsteraBox™ solution <br /><br />
            <a href="http://www.plsn.com/product-news/13367-astera-led-technologys-asterabox.html" target="_blank">READ MORE</a></p>
        </div>
        <div class="article2">
			<div class="newslogo"><a href="http://www.lumenradio.com/news.php?id=223" target="_blank"><img src="images/news/lumenradio.png"></a></div>
			<p>
			01/05/14: Astera adds Lumen Radio CRMX chips to the X-Series.
			<br /><br />
            <a href="http://www.lumenradio.com/news.php?id=223" target="_blank">READ MORE</a></p>
        </div>
        
     </div>
     <span class="border"></span>
     
      <div class="led">
         <div class="article1">
			 <div class="newslogo"><a href="http://www.lsionline.co.uk/news/story/Astera-names-exclusive-Australian-distributor/-CLLM3G" target="_blank"><img src="images/news/LSI.png"></a></div>
            <p>11/08/14: Astera names Bluebottle as the exclusive dealer for Australia and New Zealand<br /><br />
            <a href="http://www.lsionline.co.uk/news/story/Astera-names-exclusive-Australian-distributor/-CLLM3G" target="_blank">READ MORE</a></p>
        </div>
        <div class="article2">
			<div class="newslogo"><a href="http://www.plsn.com/product-news/12345-astera-spotmax-wireless-spotlight.html " target="_blank"><img src="images/news/plsn1.png"></a></div>
            <p>10/12/13: Astera launches SpotMax ™ - a milestone in wireless event lighting<br /><br />
            <a href="http://www.plsn.com/product-news/12345-astera-spotmax-wireless-spotlight.html " target="_blank">READ MORE</a></p>
        </div>
        
     </div>
  </div>  
  
<h2 class="wireless_title">
Our Partners</h2>
  <ul class="company_logos">
	  <li><a target="_blank" href="http://slidedesign.it/en"><img src="images/company_logo1.jpg"></a></li>
	  <li><a target="_blank" href="http://www.madrix.com/"><img src="images/madrix-logo.png"></a></li>
	  <li><a target="_blank" href="https://www.plasa.org/"><img src="images/company_logo6.jpg"></a></li>
	  <li><a target="_blank" href="http://www.airstar-light.com/"><img src="images/company_logo7.png"></a></li>
	  <li><a target="_blank" href="http://www.lumenradio.com/"><img src="images/lumen_radio_logo"></a></li>
  </ul> 
  <div class="clear"></div>
</div><!--end of wrapper-->


<footer>
  <div class="wrapper_960">
     <ul class="sitemap">
       <li>
	   <h3><a href="wireless.php">
	   Event Lighting</a></h3>
         <ul class="bullets">
             <li>
			 <a href="wireless.php">
	   Wireless Lights </a>
             </li>
              <li>
			 <a href="products.php">
	   Products </a>
             </li>
              <li>
			 <a href="technology.php">
	   Technology</a>
             </li>
              <li>
			 <a href="downloads.php">
	   Support & Downloads</a>
             </li>

         </ul>
       </li>
       <li>
	   <h3><a href="architectural.php">
	   Architectural Lighting</a></h3>
         <ul class="bullets">
             <li>
			 <a href="archchelsea.php">
	   Modern Retail Lighting</a>
             </li>
              <li>
			 <a href="archgardens.php">
	   Unique Chandelier</a>
             </li>
              <li>
			 <a href="archdj.php">
	   Special DJ Lighting</a>
             </li>
              <li>
			 <a href="architsu.php">
	   Restaurant Illumination</a>
             </li>
         </ul>
       </li>
	   
	   	    <li><h3>	<a href="green.php">  Green Lighting </h3><ul class="bullets"><li><a href="green_bulbs.php">Bulbs</a></li><li><a href="green_tubes.php"> Tubes</a></li><li>	<a href="green_street_light.php">				 Street Lights				</a>             </li>			 			<li>				<a href="green_control_system.php">				  Control System				</a>             </li>	       </ul> </li>		 	   
	   
       <li>
		 <h3>
		 <a href="about.php">
	   About Us		</h3>
         <ul class="bullets">
             <li><a href="about.php">Company Profile</a></li>

			
             <li>
             <a href="ManagementTeam.php">Management Team</a>
             </li>
			
			 <li>
			 <a href="contact_us.php">
			Contact Us				</a>
			</li>
			<!--
			<li>
				<a href="careers.php">
				   				</a>
             </li>
			 -->
         </ul>
       </li>
       
	   

      
     </ul>
     <div class="footer_border"></div>
        <div class="sign_wrap">
		 <h3 class="sign_in">
		 SUBSCRIBE FOR UPDATES AND OFFERS</h3>
        <form id="subscribe" action="shoot.php" method="post" name="subscribe" class="ajax_contact"  data-errorsClass='subscribe-error' data-successClass='subscribe-success'>
              <ul>
                  <li class="envelope"></li>
				  <li><input type="text" name="email" placeholder="Your Email Address" required/></li>
				  <li><button class="submit" type="submit" onClick="_gaq.push(['_trackEvent', 'TRK', 'Subscribe', 'wireless']);">
		 SUBSCRIBE</button></li>
              </ul>
              <div class="clear"></div>
         </form>
       </div>   
     <ul class="face_tube">
         <li><a href="https://www.facebook.com/AsteraLEDTechnology" target="_blank" class="facebook_group"></a></li>
         <li><a href="https://twitter.com/AsteraGlobal" target="_blank" class="twitter_group"></a></li>
         <li><a href="http://www.youtube.com/user/AsteraLED" target="_blank" class="youtube"></a></li>
     </ul>
  </div>
  
  <div class="black_strip">
       <div class="wrapper_960">
		 <p class="copyright">
		 © 2007-2014 Astera LED Technology. All Rights reserved.</p>
         <p class="muze_studio"><a href="http://www.muze-studio.co.il" target="_blank">UX Design | Web Design by Muze Studio</a></p>

		 		 <p class="muze_studio"><a target="_blank" href="imprint.php">Imprint</a>&nbsp; | </p>
		        </div>
  </div>
</footer>


<script type="text/javascript" src="source/jquery.fancybox.js"></script>
<script type="text/javascript" src="source/helpers/jquery.fancybox-media.js?v=1.0.5"></script>
<script type="text/javascript" src="js/jquery.stellar.min.js"></script>
<script src="js/jquery.bxslider.min.js"></script>
<script src="js/cycle.js"></script>

<script type="text/javascript">

 $(document).ready(function() {		
   
	   if ($(window).width() > 1024 ) {
    //big screen, load this please 
                $.stellar({
				horizontalScrolling: false,
				verticalOffset: 40
		     	});
        }
			
				$('.led').cycle({ 
			fx:     'scrollUp', 
			timeout: 6000, 
			delay:  -2000,
			pause:1 
		});
		
		  $(window).scroll(function(){
			  var pos = $(window).scrollTop();
			      target = $(".fademe_in");
				  
			  if (pos > 400){
				  target.fadeIn("slow");
			  } else {
				  target.fadeOut("slow");
			  }
			  return false;
		   });
		   
		$('.top_video').fancybox({
		openEffect  : 'none',
		closeEffect : 'none',
		helpers : {
			media : {},
			 overlay: {
                    locked: false
                }
		}
	});
 });

</script>
<script type="text/javascript" src="js/ajax_contact.js"></script>
</body>
</html>
