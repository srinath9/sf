

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="wireless, lamps, controllers, event lighting,  lighting, architectural led lighting, deco lights, led controllers," />
  <meta name="description" content="Astera LED-Technology is a manufacturer of wireless LED lights and lighting controllers for event lighting and architectural lighting." />
  <link href="/favicon.ico" rel="shortcut icon" type="image/x-icon" />


<title>Astera LED Technology - Wireless LED Solutions for Event and Architectural Lighting - Architecture DJ Light</title>
<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
<!--<script type="text/javascript" src="js/jquery.fitvids.js"></script>-->
<link href="jquery.bxslider.css" rel="stylesheet" />
<link rel="stylesheet" href="style.css" type="text/css">
<link rel="stylesheet" type="text/css" href="source/jquery.fancybox.css" media="screen" />


<script>
var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42824105-1']);
  _gaq.push(['_trackPageview']);
  _gaq.push(['_trackPageLoadTime']);


(function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
	

</script>

</head>
<body>

<header class="gradient">
 <div class="wrapper_960" style="padding:0; width:960px;">
     <a href="index.php" class="asteraLogo"><img src="images/astera_logo.png" alt="Astera Led Lighting" title="Astera Led Lighting"></a>
      <div class="lang_wrap">
	  <a class="language">中文</a>
     </div>
     <ul class="navigation">
	 <li><a href="wireless.php" >
	   无线</a></li>
	   <li><a href="architectural.php" id="onlink">
	   建筑</a></li>

 		   <li><a href="about.php" >
	   关于我们</a></li>
	   <li><a href="contact_us.php" >
	   联系我们</a></li>
	        </ul>
 </div>  
</header>
<div class="lang_strip">
   <div class="wrapper_960">
      <ul>
         <li><a href="?lang=en">English</a></li>
         <li><a href="?lang=de">Deutsch</a></li>
		 <li><a href="?lang=es">Español</a></li>
         <li><a href="?lang=cn">中文</a></li>

		 
<!--
		 <li><a>French</a></li>
		 <li><a>Italien</a></li>
		 <li><a>Spanish</a></li>
-->
      </ul>
   </div>
 </div>


<script>
$(document).ready(function() {
	$(".language").click(function () {
		$(".lang_strip").slideToggle(500);
		return false;
	}); 
});
</script>



<div class="project_nav">
   <div class="wrapper_960">
    <ul class="project_navigation">
	<li><a href="architectural.php" >Overview</a></li>
       <li><a href="archchelsea.php" >SNOG Chelsea</a></li>
       <li><a href="archgardens.php" >Gardens by the Bay</a></li>
       <li><a href="archdj.php" id="onlink">DJ Light</a></li>
       <li><a href="architsu.php" >Itsu Sushi</a></li>
       <li><a href="archlure.php" >Lure Hollywood</a></li>
       <li><a href="archbush.php" >SNOG Westfield</a></li>
       <li><a href="archsoho.php" >SNOG Soho</a></li>
     </ul>
   </div> 
 </div>




<div class="project_wrapper">
       <div class="slider_wrapper"> 
         <ul class="bxslider">
              <li><img src="images/arch/DJ_Light/1.jpg"/></li>
              <li><img src="images/arch/DJ_Light/2.jpg"/></li>
              <li><img src="images/arch/DJ_Light/3.jpg"/></li>
              <li><img src="images/arch/DJ_Light/4.jpg"/></li>
        </ul>
        <div class="data_wrapper">
           <div class="wrapper_960">
               <ul class="data_info">
                  <li>
					<h2 class="data_title">
	控制器</h2>

                    <h2><a href="javascript:;" class="data_item non-clickable">AC0 Driver</a></h2>
					<h2><a class="data_item data_item_clickable" href="Downloads/Arch datasheets/DJ Light/AC0-3 datasheet.pdf">AC0-3 datasheet</a></h2>
                  </li>
                  <li>
					<h2 class="data_title">
	光源</h2>
                    <h2><a href="javascript:;" class="data_item non-clickable">LED Flex Ribbon</a></h2>
					<h2><a class="data_item data_item_clickable" href="Downloads/Arch datasheets/DJ Light/AI1-P datasheet.pdf">AI1-P datasheet</a></h2>
                  </li>
                  <li>
					<h2 class="data_title">
	配件</h2>
                    <h2><a href="javascript:;" class="data_item non-clickable">Power/Data Distributor</a></h2>
					<h2><a id="data_item_come_up" class="data_item data_item_clickable" href="images/arch/product-overview.png">Installation Overview</a></h2>
                  </li>
                  <li style="width:340px; margin-right:0;">
					<h2 class="data_title">
	传媒</h2>
                    <ul class="tumb_images">
                      <li><a class="thumb-link" data-thumb="0"><img src="images/arch/DJ_Light/1_s.jpg"  class="grayscale"></a></li>
                      <li><a class="thumb-link" data-thumb="1"><img src="images/arch/DJ_Light/2_s.jpg"  class="grayscale"></a></li>
                      <li><a class="thumb-link" data-thumb="2"><img src="images/arch/DJ_Light/3_s.jpg" class="grayscale"></a></li>
                      <li><a class="thumb-link" data-thumb="3"><img src="images/arch/DJ_Light/4_s.jpg" class="grayscale"></a></li>
                      <li><a class="thumb-link" data-thumb="video"><img src="images/arch/DJ_Light.png" class="grayscale"></a></li>
                   </ul>
                  </li>
                  
               </ul>
           </div><!--End of wrapper_960-->
        </div><!--End of data wrapper-->
  </div><!--End of slider wrapper-->
</div><!--End of project wrapper-->

<div class="archi_text">
   <div class="wrapper_960">
     <div class="socialBar" style="margin-top:20px;">
                    <div class="facebook">
                      <div class="fb-like" data-href="http://www.astera-led.com/architectural.php" data-send="true" data-layout="button_count" data-width="120" data-show-faces="false" data-font="arial"></div>
                    </div>
                    <!--facebook_like-->
                    <div id="fb-root"></div>
                    <script>(function(d, s, id) {
                      var js, fjs = d.getElementsByTagName(s)[0];
                      if (d.getElementById(id)) return;
                      js = d.createElement(s); js.id = id;
                      js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
                      fjs.parentNode.insertBefore(js, fjs);
                    }(document, 'script', 'facebook-jssdk'));</script>
                    <!--facebook_like-->
                   <div class="twitter" data-size="small">
                      <a href="https://twitter.com/share" class="twitter-share-button" data-url="http://www.astera-led.com/architectural.php" data-via="your_screen_name" data-lang="en">Tweet</a>
                   </div> 
                    <!--twitterbutton-->
                   <script>
				   !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
                   </script>
                   <!--twitterbutton-->
                   <div class="googleplus">
                   <div class="g-plusone" data-size="medium"></div>
                   </div>
                   <!--google+button-->
					<script type="text/javascript">
                    (function() {
                      var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
                      po.src = 'https://apis.google.com/js/plusone.js';
                      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
                    })();
                  </script>
                  <!--google+button-->
                </div><!--end of social bar-->
     <div class="about_project">
	 

		 <h2>
DJ Light
<br>
融合独特创意和先进科技		 </h2>
	 <p>


	 
<br><br>

	 
</p>


     </div>

	  <a href="http://vimeo.com/72028672" class="top_video" style="display:none;"></a>
	 
     <div class="border3" style="margin-bottom:20px;"></div>
      <a href="archgardens.php" class="btn_left" style="color:#FF913E;">
	  < 前一个项目</a>
      <a href="architsu.php" class="btn_right" style="color:#FF913E;">
	  下一个项目 >
</a>
   </div>
</div><!--End of archi_text-->



<footer>
  <div class="wrapper_960">
     <ul class="sitemap">
       <li>
	   <h3><a href="wireless.php">
	   活动照明灯具</a></h3>
         <ul class="bullets">
             <li>
			 <a href="wireless.php">
	   无线灯具</a>
             </li>
              <li>
			 <a href="products.php">
	   产品</a>
             </li>
              <li>
			 <a href="technology.php">
	   技术</a>
             </li>
              <li>
			 <a href="downloads.php">
	   客户支持&下载</a>
             </li>

         </ul>
       </li>
       <li>
	   <h3><a href="architectural.php">
	   建筑照明灯具</a></h3>
         <ul class="bullets">
             <li>
			 <a href="archchelsea.php">
	   现代时尚的零售照明灯具</a>
             </li>
              <li>
			 <a href="archgardens.php">
	   独特的吊灯</a>
             </li>
              <li>
			 <a href="archdj.php">
	   DJ专业灯具</a>
             </li>
              <li>
			 <a href="architsu.php">
	   餐饮照明</a>
             </li>
         </ul>
       </li>
	   
	   	    <li><h3>	<a href="green.php">  联系我们 </h3><ul class="bullets"><li><a href="green_bulbs.php"></a></li><li><a href="green_tubes.php"> </a></li><li>	<a href="green_street_light.php">				 				</a>             </li>			 			<li>				<a href="green_control_system.php">				  				</a>             </li>	       </ul> </li>		 	   
	   
       <li>
		 <h3>
		 <a href="about.php">
	   关于我们		</h3>
         <ul class="bullets">
             <li><a href="about.php">公司简介</a></li>

			
             <li>
             <a href="ManagementTeam.php">管理团队</a>
             </li>
			
			 <li>
			 <a href="contact_us.php">
			联系我们				</a>
			</li>
			<!--
			<li>
				<a href="careers.php">
				   				</a>
             </li>
			 -->
         </ul>
       </li>
       
	   

      
     </ul>
     <div class="footer_border"></div>
        <div class="sign_wrap">
		 <h3 class="sign_in">
		 申请更新和报价</h3>
        <form id="subscribe" action="shoot.php" method="post" name="subscribe" class="ajax_contact"  data-errorsClass='subscribe-error' data-successClass='subscribe-success'>
              <ul>
                  <li class="envelope"></li>
				  <li><input type="text" name="email" placeholder="您的邮箱地址" required/></li>
				  <li><button class="submit" type="submit" onClick="_gaq.push(['_trackEvent', 'TRK', 'Subscribe', 'archdj']);">
		 订阅产品简讯</button></li>
              </ul>
              <div class="clear"></div>
         </form>
       </div>   
     <ul class="face_tube">
         <li><a href="https://www.facebook.com/AsteraLEDTechnology" target="_blank" class="facebook_group"></a></li>
         <li><a href="https://twitter.com/AsteraGlobal" target="_blank" class="twitter_group"></a></li>
         <li><a href="http://www.youtube.com/user/AsteraLED" target="_blank" class="youtube"></a></li>
     </ul>
  </div>
  
  <div class="black_strip">
       <div class="wrapper_960">
		 <p class="copyright">
		 © 2007-2014 Astera LED Technology.版权所有</p>
         <p class="muze_studio"><a href="http://www.muze-studio.co.il" target="_blank">UX Design | Web Design by Muze Studio</a></p>

		        </div>
  </div>
</footer>


<script type="text/javascript" src="source/jquery.fancybox.js"></script>
<script type="text/javascript" src="source/helpers/jquery.fancybox-media.js?v=1.0.5"></script>
<script src="js/jquery.bxslider.min.js"></script>
<script type="text/javascript">

        $(document).ready(function() {		
 
			  var slider = $('.bxslider').bxSlider({
			    adaptiveHeight: true,
				infiniteLoop: true, 
		        auto: 'true',
		        speed: '1000',
				pause: 7000,
				pager:false,
				
				});
	

				$(".thumb-link").click(function(e)
				{
				 var inx = $(this).attr("data-thumb");
				 e.preventDefault();
				 if	(inx != 'video') {
					 slider.goToSlide(inx);
				 } else {
					$(".top_video").trigger("click");
				 }
				});
			  
				
				$('.thumb-link').hover(
				 function(){ $(this).children("img").removeClass('grayscale') },
				 function(){ $(this).children("img").addClass('grayscale') });
	
	
		  
		  $(window).scroll(function(){
			  var pos = $(window).scrollTop();
			      target = $(".fademe");
				  
			  if (pos > 10){
				  target.stop(true, true).fadeOut("slow" );
			  } else {
				  target.stop(true, true).fadeIn("slow");
			  }
		   });


		$('.top_video').fancybox({
		openEffect  : 'none',
		closeEffect : 'none',
		helpers : {
			media : {},
			 overlay: {
                    locked: false
                }
		}
		});


		$('#data_item_come_up').fancybox({
		openEffect  : 'none',
		closeEffect : 'none',
		helpers : {
			media : {},
			 overlay: {
                    locked: false
                }
		}
		});
		
		  
	
    });
	
</script>
<script type="text/javascript" src="js/ajax_contact.js"></script>
</body>
</html>

